<?php
error_reporting(0);
include("../connection/db.php");

$ID = $_POST['samp'];
$date = $_POST['datecol'];



if ($date == '') {

	$arr = array('message' => 'Select Date to continue', 'title' => 'Update Response');
	echo json_encode($arr);
	exit;
} else {


	$rs = mysqli_query($dbConn, $query) or die(mysqli_error($dbConn));
	$rows = mysqli_fetch_assoc($rs);
	$no = $rows['num']; //no

	if (mysqli_affected_rows($dbConn, $rs) == 0) { //if number found

		$num = substr($no, -5); //get last part of the number e.g if no=190715_13023_00001 we get the 00001
		$namba = str_pad($num + 1, 5, 0, STR_PAD_LEFT); //then increment by 1 to get 00002
	} else //if no number found
	{
		$num = rand(1, 1);
		for ($i = 1; $i <= $num; $i++) {
			$namba = str_pad($i, 5, '0', STR_PAD_LEFT); //create the number starting with 00001
		}
	}

	$batch = "BTCH" . "_" . $namba;

	$sql = "UPDATE `drs_participants` SET dispatched='1', cond='0', batch_no='$batch',dispatch_date='$date' WHERE participant_id IN($ID)";

	//exit;
	$rsFinC = mysqli_query($dbConn, $sql) or die(mysqli_error($dbConn));

	if (!$rsFinC) {
		$arr = array('message' => 'Update Failed', 'title' => 'Update Response');
		echo json_encode($arr);
	} else {
		$arr = array('message' => 'Update Successfully done', 'title' => 'Update Response');
		echo json_encode($arr);
	}
}
