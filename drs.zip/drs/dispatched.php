<?php
include("Asidebar.php");
require_once('../connection/db.php');

$hub = $_SESSION['hub'];
$spoke = $_SESSION['mfl'];
$query_rssample = "SELECT * FROM drs_participants WHERE dispatched='1' and spoke_mfl='$spoke'";
$rssample = mysqli_query($dbConn, $query_rssample) or die(mysqli_error($dbConn));
$row_rssample = mysqli_fetch_assoc($rssample);
$total = mysqli_num_rows($rssample);
?>
<div class="page-container" style="padding-left: 35px !important">
    <?php include("Aheader.php"); ?>
    <hr />
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-gradient" data-collapsed="0">

                <div class="panel-heading">
                    <div class="panel-title">
                        All Parcipants' Samples Dispatched to CRL
                    </div>

                    <div class="panel-options">
                        <span class="tools pull-right" style="vertical-align: top">

                        </span>
                    </div>
                </div>
                <div class="panel-body">
                    <table class="table table-bordered datatable" id="table-1">
                        <thead>
                            <tr>
                                <th>DRS No </th>
                                <th>Patient Name</th>
                                <th>Date Enrolled</th>                                
                                <th>Sample Dispatch Date</th>
                                <th>Sample Details Status</th>
                                <th>Sample Processing Status</th>
                                <th>CRL Results</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php

                            if ($total == 0) {
                                # code...
                            } else {

                                do {
                                    if ($row_rssample['LABWARE_ID'] !== '') {
                                        $row_rssample['LABWARE_ID'] = 'Sample Details Recieved at CRL';
                                        $link = '';
                                    } else {
                                        $row_rssample['LABWARE_ID'] = 'Details Not yet Received';
                                    }

                                    if ($row_rssample['cond'] == '1') {
                                        $row_rssample['cond'] = 'Sample Processing in Progress';

                                        $link = '<a title="View Results" class="btn btn-info btn-sm btn-icon icon-left" data-toggle="modal" data-target="#modal-1">
                                                    <i class="entypo-eye"></i> Results
                                                </a>';
                                    } else {
                                        $row_rssample['cond'] = 'Not yet Processed';
                                    }

                                   


                            ?>
                                    <tr class="odd gradeX">
                                        <td> <?php echo $row_rssample['drs_no']; ?></td>
                                        <td> <?php echo $row_rssample['fullname']; ?></td>
                                        <td> <?php echo $row_rssample['date_enrolled']; ?></td>
                                        <td> <?php echo $row_rssample['dispatch_date']; ?></td>
                                        <td> <?php echo $row_rssample['LABWARE_ID']; ?></td>
                                        <td> <?php echo $row_rssample['cond']; ?></td>
                                        <td>
                                            <?php echo $link; ?>
                                        </td>

                                        <!-- <td></td>
                                    <a title="View Full Profile" class="btn btn-info btn-sm btn-icon icon-left" data-toggle="modal" data-target="#<?php echo $row_rssample['ID']; ?>">
                                        <i class="entypo-info"></i>
                                        &nbsp;
                                    </a>
                                   
                                </td> -->
                                    </tr>


                                    <!-- Modal -->
                                    <div class="modal" id="<?php echo $row_rssample['ID']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                    <h4 class="modal-title" id="myModalLabel">Patient Information</h4>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="col-md-4">
                                                        <label for="field1">Lab No: </label> <?php echo $row_rssample['ln']; ?>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label for="field1">Full Name: </label>
                                                        <?php echo $row_rssample['fullname']; ?>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label>Age: </label><?php echo $row_rssample['age']; ?>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label>Gender: </label><?php echo $row_rssample['gender']; ?>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label>Mobile No: </label><?php echo $row_rssample['mobile']; ?>
                                                    </div>
                                                    <div class="col-md-4"><label for="field3">Physical address: </label>
                                                        <?php echo $row_rssample['address']; ?>
                                                    </div>

                                                    <div class="col-md-4"><label for="field3">Clinician Name: </label>
                                                        <?php echo $row_rssample['c_name']; ?>
                                                    </div>

                                                    <div class="col-md-4"><label for="field3">Date of collection: </label>
                                                        <?php echo $row_rssample['coldate']; ?>
                                                    </div>
                                                </div>

                                            </div>


                                        </div>
                                    </div>

                                    <div class="modal" id="modal-1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                        <div class="modal-dialog">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header"> <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                        <h4 class="modal-title">Results from Reference Lab
                                                    </div>
                                                    <div class="modal-body">
                                                        <img height="100%" width="100%" src="results.jpeg" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            <?php } while ($row_rssample = mysqli_fetch_assoc($rssample));
                            } ?>

                        </tbody>
                    </table>
                    <!-- Modal 7 (Ajax Modal)-->
                    <div class="modal fade" id="modal-7">
                        <div class="modal-dialog">
                            <div float="right" class="modal-content" style="max-width: 500px;">

                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    <h4 class="modal-title">Update Rider for samples :<label id="samples"></label>
                                    </h4>
                                </div>

                                <div class="modal-body">

                                    <form name="save_rider" id="save_rider" class="validate" method="post" role="form">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Date of sample collection:</label>
                                                <div class="input-group">
                                                    <input type="text" name="datecol" data-validate="required" class="form-control datepicker" data-format="dd-M-yyyy" data-end-date="d" placeholder="Select Date">
                                                    <div class="input-group-addon">
                                                        <a href="#">
                                                            <i class="entypo-calendar"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <input type="hidden" id="samp" name="samp">

                                        <div class="clear"></div>
                                        <br>

                                    </form>

                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    <button class="btn btn-info" name="btnUpload" id="btnUpload" type="button" onClick="update()">Save changes</button>

                                </div>
                            </div>
                        </div>
                    </div>

                    <script type="text/javascript">
                        jQuery(document).ready(function($) {
                            $("#table-1").dataTable({
                                "sPaginationType": "bootstrap",
                                "aLengthMenu": [
                                    [10, 25, 50, -1],
                                    [10, 25, 50, "All"]
                                ],
                                "bStateSave": true
                            });

                            $(".dataTables_wrapper select").select2({
                                minimumResultsForSearch: -1
                            });
                        });
                    </script>
                </div>
            </div>
        </div>
        <!-- Footer -->
        <footer class="main">

            <div class="pull-right">
                <?php
                include 'footer.php';
                ?>
            </div>

        </footer>
    </div>
    <link rel="stylesheet" href="../assets/neon/neon-x/assets/js/select2/select2-bootstrap.css" id="style-resource-1">
    <link rel="stylesheet" href="../assets/neon/neon-x/assets/js/select2/select2.css" id="style-resource-2">

    <script src="../assets/neon/neon-x/assets/js/gsap/main-gsap.js" id="script-resource-1"></script>
    <script src="../assets/neon/neon-x/assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js" id="script-resource-2"></script>
    <script src="../assets/neon/neon-x/assets/js/bootstrap.min.js" id="script-resource-3"></script>
    <script src="../assets/neon/neon-x/assets/js/joinable.js" id="script-resource-4"></script>
    <script src="../assets/neon/neon-x/assets/js/resizeable.js" id="script-resource-5"></script>
    <script src="../assets/neon/neon-x/assets/js/neon-api.js" id="script-resource-6"></script>
    <script src="../assets/neon/neon-x/assets/js/jquery.dataTables.min.js" id="script-resource-7"></script>
    <script src="../assets/neon/neon-x/assets/js/dataTables.bootstrap.js" id="script-resource-8"></script>
    <script src="../assets/neon/neon-x/assets/js/select2/select2.min.js" id="script-resource-9"></script>
    <script src="../assets/neon/neon-x/assets/js/neon-chat.js" id="script-resource-10"></script>
    <script src="../assets/neon/neon-x/assets/js/neon-custom.js" id="script-resource-11"></script>
    <script src="../assets/neon/neon-x/assets/js/neon-demo.js" id="script-resource-12"></script>
    <script src="../assets/neon/neon-x/assets/js/toastr.js" id="script-resource-7"></script>
    <script src="../assets/neon/neon-x/assets/js/bootstrap-datepicker.js" id="script-resource-11"></script>
    <script type="text/javascript" src="../assets/js/jquery-multi-select/js/jquery.multi-select.js"></script>
    <script src="../assets/js/select2/select2.js"></script>
    <script src="../assets/js/select-init.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {


            $('#s_col').change(function() {
                var br = $("#s_col").val();
                //alert(br);

                if (br == 'C') {
                    $("#sample_col").show();
                } else {
                    $("#sample_col").hide();
                };


            }); // End of  keyup function

        }); // End of document.ready
    </script>

    </body>

    </html>