<?php
include("Asidebar.php");
//session_start();
require_once('../connection/db.php');
if (isset($_GET["id"])) {

    $ID = $_GET["id"];
} else {
    @header("location:p_view.php");
}
$hub = $_SESSION['hub'];
$user = $_SESSION['nm'];

if (isset($_POST["btnUpload"])) {

    $receipt_date = date("Y-m-j");
    $age = str_replace('_', '', $_POST['age']);
    $id_no = $_POST['id_no'];
    $fname = mysqli_real_escape_string($dbConn, $_POST['fname']);
    $mname = mysqli_real_escape_string($dbConn, $_POST['mname']);
    $lname = mysqli_real_escape_string($dbConn, $_POST['lname']);
    $fullname = $fname . ' ' . $mname . ' ' . $lname;
    $residence = mysqli_real_escape_string($dbConn, $_POST['residence']);
    $fcname = mysqli_real_escape_string($dbConn, $_SESSION['facility']);
    //exit;

    $dob = $_POST["dob"];
    $age = $_POST["age"];
    $gender = $_POST["gender"];
    $p_no = $_POST["p_no"];
    $p_no2 = $_POST["p_no2"];
    $source_of_patient = $_POST["source_of_patient"];
    $marital_status = $_POST["marital_status"];
    $education = $_POST["education"];
    $occupation = $_POST["occupation"];
    $residence = $_POST["residence"];
    $date_of_diagnosis = $_POST["date_of_diagnosis"];
    $date_enrolled = $_POST["date_enrolled"];
    $MTB_result = $_POST['MTB_Result'];
    $RIF_Result = $_POST["RIF_Result"];
    $initial_DX = $_POST["initial_DX"];

    $sickDuration = $_POST["sickDuration"];
    $date_seek_care = $_POST["date_seek_care"];
    $first_care_seek = $_POST["first_care_seek"];
    $symptoms =  $_POST["symptoms"]; // Assuming e9 is an array
    $otherSymptoms = $_POST["otherSymptoms"];
    $typeOfTB = mysqli_real_escape_string($dbConn, $_POST['typeOfTB']);
    $typeOfPatient = $_POST["typeOfPatient"];
    $treatedForTB = mysqli_real_escape_string($dbConn, $_POST['treatedForTB']);
    $rememberLastTreatment = $_POST["rememberLastTreatment"];
    $startPreviousTreatment = $_POST["startPreviousTreatment"];
    $completePreviousTreatment = $_POST["completePreviousTreatment"];
    $treatmentOutcome = mysqli_real_escape_string($dbConn, $_POST['treatmentOutcome']);
    $givenTPT = mysqli_real_escape_string($dbConn, $_POST['givenTPT']);
    $reasonForTPT = $_POST["reasonForTPT"];
    $startedOnTPT = $_POST["startedOnTPT"];
    $lastTPTTaken = $_POST["lastTPTTaken"];
    $forgotToTakeTPT = $_POST["forgotToTakeTPT"];
    $tptOutcome = $_POST["tptOutcome"];
    $knowHIVStatus = $_POST["knowHIVStatus"];
    $discloseHIVStatus = $_POST["discloseHIVStatus"];
    $hivStatus = $_POST["hivStatus"];
    $livedWithSmoker = $_POST["livedWithSmoker"];
    $everSmoked = $_POST["everSmoked"];
    $DoYouSmokeThese = $_POST["DoYouSmokeThese"];
    $dailyCigaretteConsumption = $_POST["dailyCigaretteConsumption"];
    $takingAlcohol = $_POST["takingAlcohol"];
    $daysPerWeekAlcohol = $_POST["daysPerWeekAlcohol"];
    $averageDailyAlcoholConsumption = $_POST["averageDailyAlcoholConsumption"];
    $smokeMarijuana = $_POST["smokeMarijuana"];
    $injectingDrugs = $_POST["injectingDrugs"];
    $injectionFrequency = $_POST["injectionFrequency"];
    $facilityWhereARTTaken = $_POST["facilityWhereARTTaken"];
    $artAdherenceTPT = $_POST["artAdherenceTPT"];
    $artAdherenceRecords = $_POST["artAdherenceRecords"];
    $startART = $_POST["startART"];
    $onART = $_POST["onART"];
    // SQL query to insert data into the DRS table
    $sql = "UPDATE drs_participants SET
    fname = '$fname',
    mname = '$mname',
    lname = '$lname',
    fullname = '$fullname',
    dob = '$dob',
    age = $age,
    gender = '$gender',
    id_no = '$id_no',
    p_no = '$p_no',
    pno2 = '$p_no2',
    source_of_patient = '$source_of_patient',
    marital_status = '$marital_status',
    education = '$education',
    occupation = '$occupation',
    residence = '$residence',
    date_of_diagnosis = '$date_of_diagnosis',
    date_enrolled = '$date_enrolled',
    initial_DX ='$initial_DX',
    RIF_Result='$RIF_Result',
    MTB_Result='$MTB_Result',
    sickDuration = '$sickDuration',
    date_seek_care='$date_seek_care',
    first_care_seek = '$first_care_seek',
    weight='$_POST[weight]',
    height='$_POST[height]',
    BMI='$_POST[BMI]',
    symptoms = '$symptoms',
    otherSymptoms = '$otherSymptoms',
    typeOfTB = '$typeOfTB',
    typeOfPatient = '$typeOfPatient',
    treatedForTB = '$treatedForTB',
    rememberLastTreatment = '$rememberLastTreatment',
    startPreviousTreatment = '$startPreviousTreatment',
    completePreviousTreatment = '$completePreviousTreatment',
    treatmentOutcome = '$treatmentOutcome',
    givenTPT = '$givenTPT',
    reasonForTPT = '$reasonForTPT',
    startedOnTPT = '$startedOnTPT',
    lastTPTTaken = '$lastTPTTaken',
    forgotToTakeTPT = '$forgotToTakeTPT',
    tptOutcome = '$tptOutcome',
    knowHIVStatus = '$knowHIVStatus',
    discloseHIVStatus = '$discloseHIVStatus',
    hivStatus = '$hivStatus',
    livedWithSmoker = '$livedWithSmoker',
    everSmoked = '$everSmoked',
    DoYouSmokeThese = '$DoYouSmokeThese',
    dailyCigaretteConsumption = '$dailyCigaretteConsumption',
    takingAlcohol = '$takingAlcohol',
    daysPerWeekAlcohol = '$daysPerWeekAlcohol',
    averageDailyAlcoholConsumption = '$averageDailyAlcoholConsumption',
    smokeMarijuana = '$smokeMarijuana',
    injectingDrugs = '$injectingDrugs',
    injectionFrequency = '$injectionFrequency',
    facilityWhereARTTaken = '$facilityWhereARTTaken',
    artAdherenceTPT ='$artAdherenceTPT',
    artAdherenceRecords = '$artAdherenceRecords',
    startART = '$startART',
    onART ='$onART',
    editBy='$user'
    WHERE participant_id='$ID';)";

    $retval = mysqli_query($dbConn, $sql);
    if (!$retval) {
        $msg = 0;
    } else {
        echo "<script>";
        echo "window.location.href='p_view.php'";
        echo "</script>";
    }
}

?>
<link rel="stylesheet" href="../admin/neon/neon-x/assets/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css" id="style-resource-1">
<link rel="stylesheet" href="../admin/neon/neon-x/assets/css/font-icons/entypo/css/entypo.css" id="style-resource-2">
<link rel="stylesheet" href="../admin/neon/neon-x/assets/css/font-icons/entypo/css/animation.css" id="style-resource-3">
<link rel="stylesheet" href="../admin/neon/neon-x/assets/css/neon.css" id="style-resource-5">
<link rel="stylesheet" href="../admin/neon/neon-x/assets/css/custom.css" id="style-resource-6">

<script src="../admin/neon/neon-x/assets/js/jquery-1.10.2.min.js"></script>


<div class="main-content" style="margin-top: -1%">
    <?php include("Aheader.php");     ?>
    <hr />

    <div class="row">
        <div class="col-md-12">
            <div class="panel minimal minimal-gray">
                <div class="panel-heading">
                    <!--<div class="panel-title"><h4>Presumptive Register </h4></div>

                    <div class="col-sm-5" style="float: right">
                        
                        <div class="input-group" style="max-width: 150px">
                        <label><strong><font color="red"></font>Search By Ip/Op No or TB Reg No: </strong></label>
                        <input class="form-control" type="text" name="search" id="search" autocomplete="off"><label  for="field-1">  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </label>
                        <span class="input-group-btn" style="vertical-align: bottom;"><input class="btn btn-primary" type="submit" id="btnsearch" name="btnsearch" value="Search" />
                        </span>
                        </div>

                    </div> -->

                </div>
                <div class="panel-body" id="my-div me_1">
                    <div class="panel panel-gradient" data-collapsed="0">
                        <!-- panel head -->
                        <div class="panel-heading">
                            <div class="panel-title">DRUG RESISTANCE SURVEY - Edit Survey Participant </div>
                        </div>
                        <!-- panel body -->
                        <div class="panel-body">
                            <?php
                            if (isset($_GET['msg'])) {
                                $msg = $_GET['msg'];

                                if ($msg == 1) {

                                    echo '<div style="text-align: center;width: 250px;" class="alert alert-success">Patient details successfully saved <a href="presumptive.php" data-rel="close" style="float: right;"><i class="entypo-cancel"></i></a></div>';
                                } else {

                                    echo '<div style="text-align: center;width: 250px;" class="alert alert-warning">Could not enter data.Try Again<a href="presumptive.php" data-rel="close" style="float: right;"><i class="entypo-cancel"></i></a></div>';
                                }
                            }
                            ?>
                            <form name="save" id="save" class="validate" method="post" role="form">
                                <div id="secA">
                                    <ol class="breadcrumb">
                                        <li>
                                            <a>
                                                <i class="entypo-folder"></i>
                                                SECTION A: PARTICIPANT DEMOGRAPHICS
                                            </a>
                                        </li>
                                    </ol>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font>First Name
                                                </strong></label>
                                            <input type="text" name="fname" id="fname" data-validate="required,name" class="form-control" placeholder="First Name">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font>Middle Name
                                                </strong></label>
                                            <input type="text" name="mname" id="mname" data-validate="required,name" class="form-control" placeholder="Middle Name">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font>Last Name
                                                </strong></label>
                                            <input type="text" name="lname" id="lname" data-validate="required,name" class="form-control" placeholder="Last Name">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font>Date of Birth
                                                </strong></label>
                                            <div class="input-group" style="max-width: 150px">
                                                <input type="text" id="dob" name="dob" data-validate="required" class="form-control datepicker" onchange="calculate_age()" data-format="yyyy-mm-dd" data-end-date="d" placeholder="Select Date">
                                                <div class="input-group-addon">
                                                    <a href="#">
                                                        <i class="entypo-calendar"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-1">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font>Age
                                                </strong></label>
                                            <!-- <input type="text" data-validate="required,number" name="age" id="age" class="form-control" placeholder="Age" />-->
                                            <input type="text" data-validate="required,number" maxlength="3" name="age" id="age" class="form-control" placeholder="Age" />
                                        </div>
                                    </div>
                                    <script>
                                        function calculate_age() {

                                            var birthday = $('#dob').val();
                                            var from = birthday.split("-");

                                            //alert(birthday);
                                            var now = new Date(); //Todays Date   

                                            birthday = birthday.split("-");

                                            var dobMonth = birthday[1];
                                            var dobDay = birthday[2];
                                            var dobYear = birthday[0];

                                            var nowDay = now.getDate();
                                            var nowMonth = now.getMonth() + 1; //jan = 0 so month + 1
                                            var nowYear = now.getFullYear();

                                            var ageyear = nowYear - dobYear;
                                            var agemonth = nowMonth - dobMonth;
                                            var ageday = nowDay - dobDay;
                                            if (agemonth <= 0) {
                                                ageyear--;
                                                agemonth = (12 + agemonth);
                                            }
                                            if (nowDay < dobDay) {
                                                agemonth--;
                                                ageday = 30 + ageday;
                                            }
                                            ageyear = ('0' + ageyear).slice(-2)
                                            var val = ageyear + "Y" + agemonth + "M"; // + ageday + "D"
                                            document.getElementById('age').value = ageyear;

                                            // if (ageyear < 18) {
                                            //     document.getElementById('age').value = '';
                                            //     document.getElementById('dob').value = '';
                                            //     alert("Age limit should be OVER 18 Years");

                                            // } else {
                                            //     document.getElementById('age').value = ageyear;
                                            // }
                                        };
                                    </script>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font>Sex
                                                </strong></label>
                                            <select class="form-control" style="max-width: 150px;" name="gender" id="gender" class="form-control" required>
                                                <option value="">Select One</option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                                <option value="Intersex">Intersex</option>
                                            </select>
                                        </div>
                                    </div><br>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font>ID NO
                                                </strong></label>
                                            <input type="text" data-validate="required,number" minlength="7" maxlength="8" name="id_no" id="id_no" class="form-control" placeholder="ID NO" />
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font>Patient Mobile No
                                                </strong></label>
                                            <!-- <input type="text" name="p_no" id="p_no" class="form-control" data-validate="number" maxlength="12" data-mask="999999999999" value="2547" placeholder="Patient Mobile No" data-original-title="Patient Mobile No" data-content="The number should start with the 2547 Format." data-placement="right" data-trigger="hover" data-toggle="popover" /> -->
                                            <input type="text" required name="p_no" id="p_no" class="form-control" data-validate="required,number" minlength="12" maxlength="12" placeholder="Patient Mobile No" data-original-title="Patient Mobile No" data-content="The number should start with the 2547 Format." data-placement="right" data-trigger="hover" data-toggle="popover" />
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red"></font>Alternative Mobile No
                                                </strong></label>
                                            <!-- <input type="text" name="p_no" id="p_no" class="form-control" data-validate="number" maxlength="12" data-mask="999999999999" value="2547" placeholder="Patient Mobile No" data-original-title="Patient Mobile No" data-content="The number should start with the 2547 Format." data-placement="right" data-trigger="hover" data-toggle="popover" /> -->
                                            <input type="text" name="p_no2" id="p_no2" class="form-control" data-validate="number" minlength="12" maxlength="12" placeholder="Patient Mobile No" data-original-title="Patient Mobile No" data-content="The number should start with the 2547 Format." data-placement="right" data-trigger="hover" data-toggle="popover" />
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="field-1">
                                                <strong>
                                                    <font color="red">*</font>Source of patient
                                                </strong>
                                            </label>
                                            <select class="form-control" style="max-width: 200px;" name="source_of_patient" id="source_of_patient" class="form-control" required>
                                                <option value="">Select One</option>

                                                <option value="Facility ACF">Facility ACF</option>
                                                <option value="Contact management">Contact management</option>
                                                <option value="Targeted community Outreaches">Targeted community Outreaches</option>
                                                <option value="Passive CF">Passive CF</option>
                                                <option value="Others">Others</option>
                                            </select>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="field-1">
                                                <strong>
                                                    <font color="red">*</font>Marital Status
                                                </strong>
                                            </label>
                                            <select class="form-control" style="max-width: 200px;" name="marital_status" id="marital_status" class="form-control" required>
                                                <option value="">Select One</option>
                                                <option value="Single">Single</option>
                                                <option value="Married">Married</option>
                                                <option value="Separated">Separated</option>
                                                <option value="Divorced">Divorced</option>
                                                <option value="Widow/Widower">Widow/Widower</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="field-1">
                                                <strong>
                                                    <font color="red">*</font>Education
                                                </strong>
                                            </label>
                                            <select class="form-control" style="max-width: 200px;" name="education" id="education" class="form-control" required>
                                                <option value="">Select One</option>
                                                <option value="Primary">Primary</option>
                                                <option value="Secondary">Secondary</option>
                                                <option value="Tertiary">Tertiary (College and University)</option>
                                                <option value="Other">Other</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="field-1">
                                                <strong>
                                                    <font color="red">*</font>Occupation
                                                </strong>
                                            </label>
                                            <select class="form-control" style="max-width: 200px;" name="occupation" id="occupation" class="form-control" required>
                                                <option value="">Select Dept</option>
                                                <option value="Farming">Farming</option>
                                                <option value="Business">Business</option>
                                                <option value="Formal Employment">Formal Employment</option>
                                                <option value="Informal Employment">Informal Employment</option>
                                                <option value="Pupil/Student">Pupil/Student</option>
                                                <option value="Unemployed">Unemployed</option>
                                                <option value="Others">Others (Specify)</option>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <label for="field-1"><strong>Residence</strong></label>
                                        <input type="text" name="residence" id="residence" class="form-control" placeholder="Residence">
                                    </div>

                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font>Date Enrolled
                                                </strong></label>
                                            <div class="input-group" style="max-width: 150px">
                                                <input type="text" id="date_enrolled" name="date_enrolled" data-validate="required" class="form-control datepicker" data-format="yyyy-mm-dd" data-end-date="d" placeholder="Select Date">
                                                <div class="input-group-addon">
                                                    <a href="#">
                                                        <i class="entypo-calendar"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clear"></div>
                                <br />
                                <div id="secB">
                                    <ol class="breadcrumb">
                                        <li>
                                            <a>
                                                <i class="entypo-folder"></i>
                                                Section B: CURRENT EPISODE
                                            </a>
                                        </li>
                                    </ol>
                                    <script>
                                        function toggleOtherSymptoms() {

                                        }
                                    </script>
                                    <script type="text/javascript">
                                        function bmiCalculator() {
                                            var weight = Number($('#weight').val());
                                            var height = Number($('#height').val());
                                            var finalWeight = weight;
                                            var finalHeight = height;

                                            var BMI = (finalWeight / Math.pow(finalHeight, 2));
                                            var finalBMI = Math.round((BMI), 2);
                                            document.getElementById("BMI").value = finalBMI;

                                        }
                                    </script>
                                    <!-- Question 1: FOR HOW LONG HAVE YOU BEEN SICK? -->

                                    <div class="col-md-1">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font>Weight(KGs)
                                                </strong></label>
                                            <input type="text" class="form-control" id="weight" name="weight" data-validate="required,number" placeholder="Weight" />
                                        </div>
                                    </div>
                                    <div class="col-md-1">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font>Height(M)
                                                </strong></label>
                                            <input type="text" class="form-control" onblur="bmiCalculator()" id="height" name="height" data-validate="required,number" placeholder="height" />
                                        </div>
                                    </div>

                                    <div class="col-md-1">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red"></font>BMI
                                                </strong></label>
                                            <input type="text" readonly class="form-control" id="BMI" name="BMI" placeholder="BMI" />
                                        </div>
                                    </div>

                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font>When did you start experiencing signs and symptoms for TB?
                                                </strong></label>
                                            <div class="input-group" style="max-width: 150px">
                                                <input type="text" id="sickDuration" name="sickDuration" data-validate="required" class="form-control datepicker" data-format="yyyy-mm-dd" data-end-date="d" placeholder="Select Date">
                                                <div class="input-group-addon">
                                                    <a href="#">
                                                        <i class="entypo-calendar"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font> When did you seek care for these symptoms?
                                                </strong></label>
                                            <div class="input-group" style="max-width: 150px">
                                                <input type="text" id="date_seek_care" name="date_seek_care" data-validate="required" class="form-control datepicker" data-format="yyyy-mm-dd" data-end-date="d" placeholder="Select Date">
                                                <div class="input-group-addon">
                                                    <a href="#">
                                                        <i class="entypo-calendar"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font> Where did you first seek care for these symptoms
                                                </strong></label>

                                            <input type="text" id="first_care_seek" name="first_care_seek" data-validate="required" class="form-control">

                                        </div>
                                    </div>



                                    <!-- Question 2: WHAT SYMPTOMS DO YOU HAVE? -->
                                    <div class="col-md-5">
                                        <div class="form-group">

                                            <label for="field-1"><strong>
                                                    <font color="red">*</font>What Symptoms Do You Have?
                                                </strong></label>
                                            <input type="hidden" id="symptoms" name="symptoms">

                                            <select class="form-control" name="e9" id="e9" required multiple>
                                                <option value="">Select Symptoms</option>
                                                <option value="Cough">Cough</option>
                                                <option value="Chest pain">Chest pain</option>
                                                <option value="Weight loss/ Failure to thrive">Weight loss/ Failure to thrive</option>
                                                <option value="Night sweat">Night sweat</option>
                                                <option value="Fever">Fever</option>
                                                <option value="Reduced Playfulness/ lethargy/irritability">Reduced Playfulness/ lethargy/irritability</option>
                                                <option value="Failure to thrive">Failure to thrive</option>
                                                <option value="Other">Other</option>
                                            </select>
                                        </div>
                                    </div>
                                    <script type="text/javascript">
                                        $(document).ready(function() {

                                            $('#e9').change(function() {

                                                var optionsSelected = $(this).val();
                                                document.getElementById("symptoms").value = optionsSelected;
                                                // alert(optionsSelected);

                                                // Assuming the select element has an id of "symptoms" in your HTML
                                                const selectElement = document.getElementById("e9");
                                                var otherSymptomsDiv = document.getElementById('otherSymptomsDiv');
                                                var otherSymptoms = document.getElementById('otherSymptoms');
                                                // Iterate through the selected options to check if "Other" is selected
                                                let otherSelected = false;
                                                for (let i = 0; i < selectElement.options.length; i++) {
                                                    const option = selectElement.options[i];
                                                    if (option.value === "Other" && option.selected) {
                                                        otherSelected = true;
                                                        break; // No need to continue checking if "Other" is already selected
                                                    }
                                                }

                                                if (otherSelected) {

                                                    otherSymptomsDiv.style.display = "block";
                                                    otherSymptoms.required = "true";

                                                } else {

                                                    otherSymptomsDiv.style.display = "none";
                                                }

                                            });
                                            $('#initial_DX').change(function() {
                                                var selectedOption = $(this).val();

                                                // Check if "Smear" is selected
                                                if (selectedOption === 'Smear Microscopy') {
                                                    // Clear existing options and append new ones
                                                    $('#MTB_Result').empty().append(
                                                        '<option value="">Select One</option>' +
                                                        '<option value="0-9">0-9</option>' +
                                                        '<option value="1+">1+</option>' +
                                                        '<option value="2+">2+</option>' +
                                                        '<option value="3+">3+</option>'
                                                    );

                                                    $('#RIF_Result').empty().append(
                                                        '<option value="">Select One</option>' +
                                                        '<option value="NA">NA</option>'
                                                    );

                                                } else {
                                                    $('#MTB_Result').empty().append(
                                                        '<option value="">Select One</option>' +
                                                        '<option value="Positive">Positive</option>',
                                                        '<option value="Trace">Trace</option>'
                                                    );

                                                    $('#RIF_Result').empty().append(
                                                        '<option value="">Select One</option>' +
                                                        '<option value="Positive">Positive</option>' +
                                                        '<option value="Negative">Negative</option>' +
                                                        '<option value="Inderterminate">Inderterminate</option>'

                                                    );
                                                }
                                            });
                                        });
                                    </script>

                                    <!-- Additional input for specifying other symptoms -->
                                    <div class="col-md-4" id="otherSymptomsDiv" style="display: none;">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font>Specify other symptoms:
                                                </strong></label>
                                            <input type="text" class="form-control" id="otherSymptoms" name="otherSymptoms">
                                        </div>
                                    </div>
                                </div>
                                <div class="clear"></div>
                                <br />
                                <div id="secC">
                                    <ol class="breadcrumb">
                                        <li>
                                            <a>
                                                <i class="entypo-folder"></i>
                                                SECTION C: HISTORY OF PREVIOUS TB TREATMENT
                                            </a>
                                        </li>
                                    </ol>
                                    <script>
                                        function toggleQuestions1(id, value) {
                                            var element = document.getElementById(id);
                                            if (value == 'Positive') {
                                                element.style.display = 'block';
                                            } else {
                                                element.style.display = 'none';
                                            }
                                        }
                                    </script>
                                    <script>
                                        function toggleQuestions(id, value) {
                                            var element = document.getElementById(id);
                                            if (value == 'Yes') {
                                                element.style.display = 'block';
                                            } else {
                                                element.style.display = 'none';
                                            }
                                        }
                                    </script>
                                    <!-- Question 1: PROBE FOR TYPE OF TB -->
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font>Have You Ever Been Treated For TB?
                                                </strong></label>

                                            <select class="form-control" style="max-width: 150px;" required id="treatedForTB" name="treatedForTB" onchange="toggleQuestions('everTreatedDiv', this.value)">
                                                <option value="">Select One</option>
                                                <option value="Yes">Yes</option>
                                                <option value="No">No</option>
                                                <option value="Dont know">Dont know</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div id="everTreatedDiv" style="display: none;">

                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font>Probe For Type Of TB
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 150px;" required id="typeOfTB" name="typeOfTB">
                                                    <option value="">Select One</option>
                                                    <option value="DSTB">DSTB</option>
                                                    <option value="DRTB">DRTB</option>
                                                    <option value="Dont know">Dont know</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- Question 2: TYPE OF PATIENT -->
                                        <!-- <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font>Type Of Patient
                                                </strong></label>
                                            <select class="form-control" style="max-width: 200px;" required id="typeOfPatient" name="typeOfPatient">
                                                <option value="">Select One</option>
                                                <option value="New">New</option>
                                                <option value="Previously Treated">Previously Treated</option>
                                            </select>

                                        </div>
                                    </div> -->

                                        <!-- Question 3: HAVE YOU EVER BEEN TREATED FOR TB? -->

                                        <!-- Question 4: DO YOU REMEMBER WHEN YOU WERE LAST TREATED? -->
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font>Do You Remember When You Were Last Treated?
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 150px;" required name="rememberLastTreatment" name="rememberLastTreatment" onchange="toggleQuestions('previousTBDiv', this.value)">
                                                    <option value="">Select One</option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                    <option value="Cant remember">Can't remember</option>
                                                </select>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- Additional questions for when treatment was remembered -->
                                    <div id="previousTBDiv" style="display: none;">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> When Did You Start Your Previous TB Treatment?
                                                    </strong></label>
                                                <div class="input-group" style="max-width: 150px">
                                                    <input type="text" id="startPreviousTreatment" name="startPreviousTreatment" data-validate="required" class="form-control datepicker" data-format="yyyy-mm" data-start-view="2" data-minviewmode="months" data-end-date="d" placeholder="Select Date">
                                                    <div class="input-group-addon">
                                                        <a href="#">
                                                            <i class="entypo-calendar"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> When Did You Complete The Previous TB Treatment?
                                                    </strong></label>
                                                <div class="input-group" style="max-width: 150px">
                                                    <input type="text" id="completePreviousTreatment" name="completePreviousTreatment" data-validate="required" class="form-control datepicker" data-format="yyyy-mm" data-start-view="2" data-minviewmode="months" data-end-date="d" placeholder="Select Date">
                                                    <div class="input-group-addon">
                                                        <a href="#">
                                                            <i class="entypo-calendar"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> What Was Your Treatment Outcome?
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" required id="treatmentOutcome" name="treatmentOutcome">
                                                    <option value="">Select One</option>
                                                    <option value="Cured">Cured</option>
                                                    <option value="Treatment Complete">Treatment Complete</option>
                                                    <option value="Dont know">Dont know</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>


                                </div>
                                <div class="clear"></div>
                                <br />
                                <div id="secD">
                                    <ol class="breadcrumb">
                                        <li>
                                            <a>
                                                <i class="entypo-folder"></i>
                                                SECTION D: TB PREVENTIVE THERAPY
                                            </a>
                                        </li>
                                    </ol>
                                    <!-- Question 1: HAVE YOU EVER BEEN GIVEN TB PREVENTIVE THERAPY (TPT)? -->
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="field-1"><strong>
                                                    <font color="red">*</font>Have You Ever Been Given TB Preventive Therapy (TPT)?
                                                </strong></label>
                                            <select class="form-control" required style="max-width: 200px;" id="givenTPT" name="givenTPT" onchange="toggleQuestions('TPTYes', this.value)">
                                                <option value="">Select One</option>
                                                <option value="Yes">Yes</option>
                                                <option value="No">No</option>
                                                <option value="Dont Know">Dont Know</option>
                                            </select>
                                        </div>
                                    </div>

                                    <!-- Question 1a: FOR WHAT REASON WERE GIVEN DRUGS TO PREVENT DEVELOPMENT OF ACTIVE TB -->
                                    <div id="TPTYes" style="display: none;">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> For What Reason Were Given Drugs To Prevent Development Of Active TB
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" id="reasonForTPT" name="reasonForTPT">
                                                    <option value="">Select One</option>
                                                    <option value="Household Contacts">Household Contacts</option>
                                                    <option value="Prisoners">Prisoners</option>
                                                    <option value="PLHIVs">PLHIVs</option>
                                                    <option value="Other Clinical Risk Groups">Other Clinical Risk Groups</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- Question 1c: IF YES, WHEN WERE YOU STARTED ON TPT? -->
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> If Yes, When Were You Started On TPT?
                                                    </strong></label>
                                                <div class="input-group" style="max-width: 150px">
                                                    <input type="text" id="startedOnTPT" name="startedOnTPT" data-validate="required" class="form-control datepicker" data-format="yyyy-mm" data-start-view="2" data-minviewmode="months" data- data-end-date="d" placeholder="Select Date">
                                                    <div class="input-group-addon">
                                                        <a href="#">
                                                            <i class="entypo-calendar"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <!-- Question 1d: WHEN DID YOU LAST TAKE YOUR TPT MEDICINE? -->
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> When Did You Last Take Your TPT Medicine?
                                                    </strong></label>
                                                <div class="input-group" style="max-width: 150px">
                                                    <input type="text" id="lastTPTTaken" name="lastTPTTaken" data-validate="required" class="form-control datepicker" data-format="yyyy-mm" data-start-view="2" data-minviewmode="months" data-end-date="d" placeholder="Select Date">
                                                    <div class="input-group-addon">
                                                        <a href="#">
                                                            <i class="entypo-calendar"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Question 1e: DID YOU AT ANY POINT FORGET TO TAKE TPT MEDICINE? -->
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> Did You At Any Point Forget To Take TPT Medicine?
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" id="forgotToTakeTPT" name="forgotToTakeTPT" required>
                                                    <option value="">Select One</option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                    <option value="Dont know">Dont know</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- Question 1g: PROBE FOR FREQUENCY AND DURATION OF TPT AND DEDUCE POSSIBLE REGIMEN TAKEN 
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> Probe For Frequency And Duration Of TPT And Deduce Possible Regimen Taken
                                                    </strong></label>
                                              
                                            </div>
                                        </div>-->

                                        <!-- Question 1h: WHAT WAS THE TPT OUTCOME? -->
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> What Was The TPT Outcome?
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" id="tptOutcome" name="tptOutcome" required>
                                                    <option value="">Select One</option>
                                                    <option value="Completed">Completed</option>
                                                    <option value="Discontinued">Discontinued</option>
                                                    <option value="Other">Other</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clear"></div>
                                <br />
                                <div id="secE">
                                    <ol class="breadcrumb">
                                        <li>
                                            <a>
                                                <i class="entypo-folder"></i>
                                                SECTION E: HIV STATUS
                                            </a>
                                        </li>
                                    </ol>

                                    <!-- Question 1: DO YOU KNOW YOUR HIV STATUS -->
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> Do You Know Your HIV Status
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" required id="knowHIVStatus" name="knowHIVStatus" onchange="toggleQuestions('DiscloseYes', this.value)">
                                                    <option value="">Select One</option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- Question 1A: IF YES, ARE YOU WILLING TO DISCLOSE YOUR STATUS TO THE INTERVIEWER -->
                                        <div class="col-md-3" id="DiscloseYes" style="display: none;">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> If Yes, Are You Willing To Disclose Your Status To The Interviewer
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" required id="discloseHIVStatus" name="discloseHIVStatus" onchange="toggleQuestions('Hivstat', this.value)">
                                                    <option value="">Select One</option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                    <option value="Not sure">Not sure</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- Question 1B: IF YES, WHAT IS YOUR HIV STATUS -->
                                        <div class="col-md-3" id="Hivstat" style="display: none;">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> If Yes What Is Your HIV Status
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" required name="hivStatus" id="hivStatus" onchange="toggleQuestions1('onARTDiv', this.value)">
                                                    <option value="">Select One</option>
                                                    <option value="Positive">Positive</option>
                                                    <option value="Negative">Negative</option>
                                                    <option value="Declined">Declined</option>
                                                    <option value="Not Done">Not Done</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3" id="onARTDiv" style="display: none;">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> If HIV Positive, Are You On ART?
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" required name="onART" id="onART" onchange="toggleQuestions('StartARTDiv', this.value)">
                                                    <option value="">Select One</option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div id="StartARTDiv" style="display: none;">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="field-1"><strong>
                                                            <font color="red">*</font> If Yes, Date Started On ART
                                                        </strong></label>

                                                    <div class="input-group" style="max-width: 150px">
                                                        <input type="text" id="startART" name="startART" data-validate="required" class="form-control datepicker" data-format="yyyy-mm" data-start-view="2" data-minviewmode="months" data-end-date="d" placeholder="Select Date">
                                                        <div class="input-group-addon">
                                                            <a href="#">
                                                                <i class="entypo-calendar"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="field-1"><strong>
                                                            <font color="red">*</font> If Taking ART In The Same Facility, Check Records On Current ART Adherence
                                                        </strong></label>
                                                    <select class="form-control" name="artAdherenceRecords" id="artAdherenceRecords" required>
                                                        <option value="">Select One</option>
                                                        <option value="Good">Good</option>
                                                        <option value="Fair">Fair</option>
                                                        <option value="Poor">Poor</option>
                                                        <option value="Not Applicable">Not Applicable</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <!-- Question 1f: If Taking ART In The Same Facility, Check Records On ART Adherence During TPT Uptake -->
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="field-1"><strong>
                                                            <font color="red">*</font> If Taking ART In The Same Facility, Check Records On ART Adherence During TPT Uptake
                                                        </strong></label>
                                                    <select class="form-control" name="artAdherenceTPT" id="artAdherenceTPT" required>
                                                        <option value="">Select One</option>
                                                        <option value="Good">Good</option>
                                                        <option value="Fair">Fair</option>
                                                        <option value="Poor">Poor</option>
                                                        <option value="Not Applicable">Not Applicable</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <!-- Question 1g: If Not On ART At The Current Facility, Indicate The Facility Where The ART Is Taken -->
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="field-1"><strong>
                                                            <font color="red">*</font> If Not On ART At The Current Facility, Indicate The Facility Where The ART Is Taken</p>
                                                            <input type="text" class="form-control" name="facilityWhereARTTaken" id="facilityWhereARTTaken">
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="clear"></div>
                                <br />
                                <div id="secF">
                                    <ol class="breadcrumb">
                                        <li>
                                            <a>
                                                <i class="entypo-folder"></i>
                                                SECTION F: SUBSTANCE USE
                                            </a>
                                        </li>
                                    </ol>
                                    <div class="row">
                                        <!-- Question 1: HAVE YOU EVER LIVED WITH SOMEONE WHO SMOKES? -->
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> Have You Ever Lived With Someone Who Smokes?
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" required name="livedWithSmoker" id="livedWithSmoker">
                                                    <option value="">Select One</option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- Question 2: HAVE YOU EVER SMOKED? -->
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> Have You Ever Smoked?
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" required id="everSmoked" name="everSmoked" onchange="toggleQuestions('smokingAny', this.value)">
                                                    <option value="">Select One</option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- Question 2a: IF YES, DO YOU CURRENTLY SMOKE ANY OF THE FOLLOWING? -->

                                        <script type="text/javascript">
                                            $(document).ready(function() {

                                                $('#DoYouSmokeTheseCigarette').change(function() {

                                                    var cigaretteCheckbox = document.getElementById("DoYouSmokeTheseCigarette");

                                                    // Get a reference to the div you want to show/hide
                                                    var cigaretteDiv = document.getElementById("cigaretteDiv");

                                                    if (cigaretteCheckbox.checked) {
                                                        // If the checkbox is checked, show the div
                                                        cigaretteDiv.style.display = "block";
                                                    } else {
                                                        // If the checkbox is unchecked, hide the div
                                                        cigaretteDiv.style.display = "none";
                                                    }

                                                });
                                            });
                                        </script>
                                        <div class="col-md-3" id="smokingAny" style="display: none;">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> If Yes, Do You Currently Smoke Any Of The Following?
                                                    </strong></label>
                                                <!-- <select name="DoYouSmokeThese" id="DoYouSmokeThese" class="form-control" required multiple>
                                                <option value="">Select One</option>
                                                <option value="Cigarette">Cigarette</option>
                                                <option value="Shisha">Shisha</option>
                                                <option value="Tobacco Sniffing">Tobacco Sniffing</option>
                                            </select> -->
                                                <label class="checkbox-inline">
                                                    <input type="checkbox" name="DoYouSmokeThese[]" id="DoYouSmokeTheseCigarette" value="Cigarette"> Cigarette
                                                </label>
                                                <label class="checkbox-inline">
                                                    <input type="checkbox" name="DoYouSmokeThese[]" id="DoYouSmokeTheseShisha" value="Shisha"> Shisha
                                                </label>
                                                <label class="checkbox-inline">
                                                    <input type="checkbox" name="DoYouSmokeThese[]" id="DoYouSmokeTheseTobacco" value="Tobacco Sniffing"> Tobacco Sniffing
                                                </label>

                                            </div>
                                        </div>

                                        <!-- Question 2b: IF YES FOR CIGARETTES, HOW MANY PACKS OF CIGARETTES DO YOU CURRENTLY SMOKE EACH DAY ON AVERAGE? -->
                                        <div class="col-md-3" id="cigaretteDiv" style="display: none;">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> How Many Packs Of Cigarettes Do You Currently Smoke Each Day On Average?
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" required name="dailyCigaretteConsumption" id="dailyCigaretteConsumption">
                                                    <option value="">Select One</option>
                                                    <option value="Less Than 1 Pack Per Day">Less Than 1 Pack Per Day</option>
                                                    <option value="More Than 1 Pack Per Day">More Than 1 Pack Per Day</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- Question 3: ARE YOU CURRENTLY TAKING ALCOHOL? -->
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> Are You Currently Taking Alcohol?
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" required name="takingAlcohol" id="takingAlcohol" onchange="toggleQuestions('drinkingAny', this.value)">
                                                    <option value="">Select One</option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- Question 3a: IF YES TO QUESTION 3, HOW MANY DAYS PER WEEK DO YOU DRINK ALCOHOL? -->
                                        <div id="drinkingAny" style="display: none;">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="field-1"><strong>
                                                            <font color="red">*</font> How Many Days Per Week Do You Drink Alcohol?
                                                        </strong></label>
                                                    <select class="form-control" style="max-width: 200px;" required name="daysPerWeekAlcohol" id="daysPerWeekAlcohol">
                                                        <option value="">Select One</option>
                                                        <option value="1 Day">1 Day</option>
                                                        <option value="2-3 Days">2-3 Days</option>
                                                        <option value="3-4 Days">3-4 Days</option>
                                                        <option value="5-7 Days">5-7 Days</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <!-- Question 3b: IF YES TO QUESTION 3, HOW MUCH DO YOU DRINK DURING AN AVERAGE DAY? -->
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="field-1"><strong>
                                                            <font color="red">*</font> How Much Do You Drink During An Average Day?
                                                        </strong></label>
                                                    <select class="form-control" style="max-width: 200px;" required name="averageDailyAlcoholConsumption" id="averageDailyAlcoholConsumption" data-original-title="Drinking Alcohol" data-content="One Drink Equals One Beer Or One Glass Of Wine Or One Shot Of Hard Liquor Or Mixed Drink" data-placement="top" data-trigger="hover" data-toggle="popover">
                                                        <option value="">Select One</option>
                                                        <option value="1 Drink">1 Drink</option>
                                                        <option value="1-3 Drinks">1-3 Drinks</option>
                                                        <option value="4 Drinks">4 Drinks</option>
                                                        <option value="5 Or More Drinks">5 Or More Drinks</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Question 4: DO YOU CURRENTLY SMOKE MARIJUANA? -->
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> Do You Currently Smoke Marijuana?
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" required name="smokeMarijuana" id="smokeMarijuana">
                                                    <option value="">Select One</option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <!-- Question 5: ARE YOU CURRENTLY INJECTING YOURSELF WITH DRUGS? -->
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> Are You Currently Injecting Yourself With Drugs?
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" required name="injectingDrugs" id="injectingDrugs" onchange="toggleQuestions('injecting', this.value)">
                                                    <option value="">Select One</option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- Question 5a: IF YES, HOW OFTEN DO YOU INJECT YOURSELF? -->
                                        <div class="col-md-3" id="injecting" style="display: none;">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> If Yes, How Often Do You Inject Yourself?
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" required name="injectionFrequency" id="injectionFrequency">
                                                    <option value="">Select One</option>
                                                    <option value="Daily">Daily</option>
                                                    <option value="Once Per Week">Once Per Week</option>
                                                    <option value="Twice In A Week">Twice In A Week</option>
                                                    <option value="More Than Thrice In A Week">More Than Thrice In A Week</option>
                                                    <option value="Other">Other</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clear"></div>
                                <br />
                                <div id="secG">
                                    <ol class="breadcrumb">
                                        <li>
                                            <a>
                                                <i class="entypo-folder"></i>
                                                SECTION G: MICROSCOPY/XPERT/ANY OTHER MOLECULAR ASSAY RESULTS
                                            </a>
                                        </li>
                                    </ol>
                                    <div id="initial_DX_DIV"><!-- //style="display: none;" -->
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> Initial Test Done
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" id="initial_DX" name="initial_DX" required>
                                                    <option value="">Select One</option>
                                                    <option value="GeneXpert">GeneXpert</option>
                                                    <option value="TrueNat">TrueNat</option>
                                                    <option value="Smear Microscopy">Smear Microscopy</option>
                                                    <option value="TB LAMP">TB LAMP</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> MTB RESULT
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" id="MTB_Result" name="MTB_Result" required>
                                                    <option value="">Select One</option>
                                                    <option value="Positive">Positive</option>
                                                    <option value="Trace">Trace</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font> RIF Result
                                                    </strong></label>
                                                <select class="form-control" style="max-width: 200px;" id="RIF_Result" name="RIF_Result" required>
                                                    <option value="">Select One</option>
                                                    <option value="Positive">Positive</option>
                                                    <option value="Negative">Negative</option>
                                                    <option value="Inderterminate">Inderterminate</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for="field-1"><strong>
                                                        <font color="red">*</font>Date of Diagnosis
                                                    </strong></label>
                                                <div class="input-group" style="max-width: 150px">
                                                    <input type="text" id="date_of_diagnosis" name="date_of_diagnosis" data-validate="required" class="form-control datepicker" data-format="yyyy-mm-dd" data-start-date="-1w" data-end-date="d" placeholder="Select Date">
                                                    <div class="input-group-addon">
                                                        <a href="#">
                                                            <i class="entypo-calendar"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clear"></div>
                                <br />
                                <div class="col-md-12" align="center">
                                    <button class="btn btn-success" type="submit" name="btnUpload" id="btnUpload">Update Details</button>
                                    <button class="btn" type="reset">Reset</button>
                                </div>

                            </form>

                        </div>

                    </div>


                </div>

            </div>

        </div>
    </div>

    <!-- Footer -->
    <footer class="main">

        <div class="pull-right">
            <?php
            include 'footer.php';
            ?>
        </div>

    </footer>
</div>
<link rel="stylesheet" href="../assets/neon/neon-x/assets/js/select2/select2-bootstrap.css" id="style-resource-1">
<link rel="stylesheet" href="../assets/neon/neon-x/assets/js/select2/select2.css" id="style-resource-2">



<script src="../assets/neon/neon-x/assets/js/gsap/main-gsap.js" id="script-resource-1"></script>
<script src="../assets/neon/neon-x/assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js" id="script-resource-2"></script>
<script src="../assets/neon/neon-x/assets/js/bootstrap.min.js" id="script-resource-3"></script>
<script src="../assets/neon/neon-x/assets/js/joinable.js" id="script-resource-4"></script>
<script src="../assets/neon/neon-x/assets/js/resizeable.js" id="script-resource-5"></script>
<script src="../assets/neon/neon-x/assets/js/neon-api.js" id="script-resource-6"></script>
<script src="../assets/neon/neon-x/assets/js/bootstrap-datepicker.js" id="script-resource-11"></script>
<script src="../assets/neon/neon-x/assets/js/jquery.validate.min.js" id="script-resource-7"></script>
<script src="../assets/neon/neon-x/assets/js/jquery.inputmask.bundle.min.js" id="script-resource-7"></script>
<script src="../assets/neon/neon-x/assets/js/select2/select2.min.js" id="script-resource-7"></script>
<script src="../assets/neon/neon-x/assets/js/neon-chat.js" id="script-resource-8"></script>
<script src="../assets/neon/neon-x/assets/js/bootstrap-tagsinput.min.js" id="script-resource-8"></script>


<link rel="stylesheet" href="../assets/neon/neon-x/assets/js/select2/select2-bootstrap.css" id="style-resource-1">
<link rel="stylesheet" href="../assets/neon/neon-x/assets/js/select2/select2.css" id="style-resource-2">
<script src="../assets/neon/neon-x/assets/js/bootstrap-tagsinput.min.js" id="script-resource-8"></script>
<script src="../assets/neon/neon-x/assets/js/jquery.inputmask.bundle.min.js" id="script-resource-7"></script>
<script src="../assets/neon/neon-x/assets/js/gsap/main-gsap.js" id="script-resource-1"></script>
<script src="../assets/neon/neon-x/assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js" id="script-resource-2"></script>
<script src="../assets/neon/neon-x/assets/js/bootstrap.min.js" id="script-resource-3"></script>
<script src="../assets/neon/neon-x/assets/js/joinable.js" id="script-resource-4"></script>
<script src="../assets/neon/neon-x/assets/js/resizeable.js" id="script-resource-5"></script>
<script src="../assets/neon/neon-x/assets/js/neon-api.js" id="script-resource-6"></script>
<script src="../assets/neon/neon-x/assets/js/jquery.dataTables.min.js" id="script-resource-7"></script>
<script src="../assets/neon/neon-x/assets/js/dataTables.bootstrap.js" id="script-resource-8"></script>
<script src="../assets/neon/neon-x/assets/js/select2/select2.min.js" id="script-resource-9"></script>
<script src="../assets/neon/neon-x/assets/js/neon-chat.js" id="script-resource-10"></script>
<script src="../assets/neon/neon-x/assets/js/neon-custom.js" id="script-resource-11"></script>
<script src="../assets/neon/neon-x/assets/js/neon-demo.js" id="script-resource-12"></script>
<script src="../assets/neon/neon-x/assets/js/toastr.js" id="script-resource-7"></script>
<script src="../assets/neon/neon-x/assets/js/bootstrap-datepicker.js" id="script-resource-11"></script>
<script type="text/javascript" src="../assets/js/jquery-multi-select/js/jquery.multi-select.js"></script>
<script src="../assets/js/select2/select2.js"></script>
<script src="../assets/js/select-init.js"></script>
<script type="text/javascript">
    function FungetID() {

        var queryString = window.location.search.substring(1);
        var varArray = queryString.split("="); //eg. index.html?msg=1

        var param1 = varArray[0];
        var param2 = varArray[1];
        // alert(param2);
        //exit;
        //document.getElementById('id1').value= param2 ; 
        jQuery.ajax({
            type: "POST",
            url: "fix.php",
            data: 'id=' + param2,
            cache: false,
            dataType: "json",
            success: function(data) {
                $.each(data, function(i, v) {
                    $("#" + i).val(v)
                });
                var studentSelect = $('#e9');
                var option = new Option(data.symptoms, data.symptoms, true, true);
                studentSelect.append(option).trigger('change');

                //$('select[value="Yes"]').trigger('change');,,,
                $('#rememberLastTreatment').trigger('change');
                $('#givenTPT').trigger('change');
                $('#knowHIVStatus').trigger('change');
                $('#discloseHIVStatus').trigger('change');
                $('#hivStatus').trigger('change');
                $('#onART').trigger('change');
                $('#everSmoked').trigger('change');
                $('#takingAlcohol').trigger('change');
                $('#injectingDrugs').trigger('change');
                $('#initial_DX').trigger('change');
                $('#treatedForTB').trigger('change');
                $('#treatedForTB').trigger('change');

                if (data.DoYouSmokeThese === 'Cigarette') {
                    $('#DoYouSmokeTheseCigarette').prop('checked', true);
                } else if (data.DoYouSmokeThese === 'Shisha') {
                    $('#DoYouSmokeTheseShisha').prop('checked', true);
                } else if (data.DoYouSmokeThese === 'Tobacco Sniffing') {
                    $('#DoYouSmokeTheseTobacco').prop('checked', true);
                }
            }
        });
    }
</script>
<script type="text/javascript">
    $(document).ready(function() {
        var queryString = window.location.search.substring(1);
        var varArray = queryString.split("="); //eg. index.html?msg=1
        var param1 = varArray[0];

        if (param1 != 'id') {

        } else {
            //alert(param1);
            var id = varArray[1];
            if (typeof param1 !== 'undefined' || param1 !== null) {
                FungetID();
            } else {

            }
        }
    }); // End of document.ready
</script>


</html>