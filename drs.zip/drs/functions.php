<?php
//session_start();
require_once('../connection/db.php');

function postToLabware($id)
{
    global $dbConn;

    $sql = "SELECT participant_id,drs_no,fname,mname,lname,fullname,id_no,dob,age,gender,p_no,pno2,source_of_patient,marital_status,education,occupation,residence,hub_mfl,hub_name,hub_subcounty,hub_county,spoke_mfl,spoke_name,spoke_subcounty,spoke_county,clinician_email,clinician_phone,date_of_diagnosis,initial_DX,MTB_Result,RIF_Result,date_enrolled,dispatch_date,drs_lab_bc,batch_no,
    sickDuration,symptoms,otherSymptoms,typeOfTB,typeOfPatient,treatedForTB,rememberLastTreatment,startPreviousTreatment,completePreviousTreatment,treatmentOutcome,givenTPT,reasonForTPT,startedOnTPT,lastTPTTaken,forgotToTakeTPT,tptOutcome,knowHIVStatus,discloseHIVStatus,hivStatus,facilityWhereARTTaken,artAdherenceTPT,artAdherenceRecords,startART,onART,livedWithSmoker,everSmoked,DoYouSmokeThese,
    dailyCigaretteConsumption,takingAlcohol,daysPerWeekAlcohol,averageDailyAlcoholConsumption,smokeMarijuana,injectingDrugs,injectionFrequency
    FROM drs_participants where participant_id='$id'";
    $checkSample = mysqli_query($dbConn, $sql) or die(mysqli_error($dbConn));
    $row_rsFinC = mysqli_fetch_assoc($checkSample);

    $contactemail = $row_rsFinC['clinician_email'];
    $Drs_no = $row_rsFinC['drs_no'];

    $push_data = json_encode($row_rsFinC);
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://dx.nphl.go.ke/webhook/tb-drs-requests',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => $push_data,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Authorization: Bearer 9f3edd6a99d95291a54e0d351af22f33'
        ),
    ));

    $response = curl_exec($curl);

    curl_close($curl);
    // echo $response;

    $data = json_decode($response, true);
    if (isset($data['message'])) {
        echo $data['message'];
    } else {
        $drs_no = mysqli_real_escape_string($dbConn, $data['drs_no']);
        $DATE_Recieved = mysqli_real_escape_string($dbConn, $data['DATE_Recieved']);
        $LABWARE_ID = mysqli_real_escape_string($dbConn, $data['LABWARE_ID']);
        $participant_id = mysqli_real_escape_string($dbConn, $data['participant_id']);

        $sql = "UPDATE `drs_participants` SET LABWARE_ID='$LABWARE_ID', cond='1',datetimelogged_LW='$DATE_Recieved'  WHERE participant_id='$participant_id' and drs_no='$drs_no'";
        //exit;
        $rsFinC = mysqli_query($dbConn, $sql) or die(mysqli_error($dbConn));

        if (!$rsFinC) {
            // $arr = array('message' => 'Update Failed', 'title' => 'Update Response');
            // echo json_encode($arr);
        } else {
            // $arr = array('message' => 'Update Successfully done', 'title' => 'Update Response');
            // echo json_encode($arr);
            require('../phpmailer/class.phpmailer.php');
            $mail = new PHPMailer();
            $mail->IsSMTP();
            $mail->Host = "smtp.gmail.com";
            $mail->SMTPAuth = true;
            $subject = "New DRS Participant Notification";
            $SEmail = 'tibulimsalerts@gmail.com';
            $mail->Username = $SEmail;
            $mail->Password = 'gbjohybkyahjxbqe';// :
            // $mail->Username = genexpert.nltp@gmail.com;
            // $mail->Password = 'axslaegzhbatpmna';
            $mail->SMTPDebug = 1;  // debugging: 1 = errors and messages, 2 = messages only
            $mail->SMTPSecure = 'tls'; //tls secure transfer enabled REQUIRED for Gmail
            $mail->Port = 587; //25 //587
            $mail->From = $SEmail;
            $mail->FromName = "TIBULIMS";
            $mail->Sender = $SEmail;
            $mail->AddAddress($contactemail);

            $mail->Subject = $subject;
            $mail->IsHTML(TRUE);

            //$mail->AddStringAttachment($doc, $reporttitle, 'base64', 'application/pdf');
            $mail->Body = "
			Hello,<br>
			
			Details of the new DRS participant($Drs_no) have been pushed to LABWARE-CRL at $DATE_Recieved. Kindly ensure that the participants sample is dispatched to CRL ASAP for testing.<br> 
				
			<br> Many Thanks.<br>
			-- <br>
			TIBULIMS DRS Team <br>
			This email was automatically generated. Please do not respond to this email address since it will be ignored.";
            if (!$mail->Send()) {
            } else {
            }
        }
    }
}

//echo postToLabware(4);
