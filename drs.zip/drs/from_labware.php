

<?php
//http://tibulims.dltld.or.ke/ntbrl/drs/from_labware.php
//error_reporting(0);
require_once('../connection/db.php');
header("Content-Type:application/json");

$json1 = file_get_contents('php://input');
$data = json_decode($json1, true);

//print_r($entry);
foreach ($data as $entry) {

    $ENTERED_ON = $entry['ENTERED_ON'];
    $SAMPLE_NUMBER = mysqli_real_escape_string($dbConn, $entry['SAMPLE_NUMBER']);
    $STUDY_ID = mysqli_real_escape_string($dbConn, $entry['STUDY_ID']);
    $lab_id = mysqli_real_escape_string($dbConn, $entry['lab_id']);
    $ANALYSIS = mysqli_real_escape_string($dbConn, $entry['ANALYSIS']);
    $component = mysqli_real_escape_string($dbConn, $entry['component']);
    $result = mysqli_real_escape_string($dbConn, $entry['result']);
    $date_tested = mysqli_real_escape_string($dbConn, $entry['ENTERED_ON']);

    $insert = "INSERT INTO `drs_results` (`ENTERED_ON`, `SAMPLE_NUMBER`, `STUDY_ID`, `lab_id`, `ANALYSIS`, `component`, `result`, `date_tested`) 
   VALUES ('$ENTERED_ON', '$SAMPLE_NUMBER', '$STUDY_ID', '$lab_id', '$ANALYSIS', '$component', '$result', '$date_tested');";

    $retval = mysqli_query($dbConn, $insert);
    if ($retval) {
        echo "Data inserted successfully\n";

        $sql = "SELECT clinician_email,clinician_phone from drs_participants where drs_no='$STUDY_ID'";
        $checkSample = mysqli_query($dbConn, $sql) or die(mysqli_error($dbConn));
        $row_rsFinC = mysqli_fetch_assoc($checkSample);
        $contactemail = $row_rsFinC['clinician_email'];

        require('../phpmailer/class.phpmailer.php');
        $mail = new PHPMailer();
        $mail->IsSMTP();
        $mail->Host = "smtp.gmail.com";
        $mail->SMTPAuth = true;
        $subject = "DRS Participant($STUDY_ID) Result Notification-".$ANALYSIS;
        //$mail->Username = 'genexpert.nltp@gmail.com';
        //$mail->Password = 'gxlims@2015!';
        $mail->Username = 'genexpert.nltp@gmail.com';
        $mail->Password = 'axslaegzhbatpmna';
        $mail->SMTPDebug = 1;  // debugging: 1 = errors and messages, 2 = messages only
        $mail->SMTPSecure = 'tls'; //tls secure transfer enabled REQUIRED for Gmail
        $mail->Port = 587; //25 //587
       
        $mail->From = "genexpert.nltp@gmail.com";
        $mail->FromName = "TIBULIMS";
        $mail->Sender = "genexpert.nltp@gmail.com";
        $mail->AddAddress($contactemail);

        $mail->Subject = $subject;
        $mail->IsHTML(TRUE);

        //$mail->AddStringAttachment($doc, $reporttitle, 'base64', 'application/pdf');
        $mail->Body = "
        Hello,<br>
        
        $ANALYSIS result for DRS participant($STUDY_ID) have been released at $date_tested. The results are $component-$result.<br> 
            
        <br> Many Thanks.<br>
        -- <br>
        TIBULIMS DRS Team <br>
        This email was automatically generated. Please do not respond to this email address since it will be ignored.";
        if (!$mail->Send()) {
            echo  "Mailer Error: " . $mail->ErrorInfo;
        } else {

            echo " mail sent";
        }

    } else {
        echo "Failed to insert data\n";

       
    }
}

// 

// exit;
