<!DOCTYPE html>
<html>

<head>
    <title>Barcode Scanner Example</title>
</head>

<body>
    <form>
        <label for="barcodeInput">Scan Barcode:</label>
        <input type="text" id="barcodeInput" name="barcode" readonly>
        <button type="button" id="scanButton">Scan</button>
    </form>

    <div id="interactive" class="viewport"></div>

    <script src="https://cdn.jsdelivr.net/npm/quagga"></script>
    <script>
        const barcodeInput = document.getElementById("barcodeInput");
        const scanButton = document.getElementById("scanButton");


        scanButton.addEventListener("click", function() {
            // Initialize QuaggaJS
            Quagga.init({
                inputStream: {
                    name: "Live",
                    type: "LiveStream",
                    target: document.querySelector('#interactive'),
                },
                decoder: {
                    readers: ['ean_reader', 'upc_reader', 'code_128_reader'],
                },
            }, function(err) {
                if (err) {
                    console.error(err);
                    return;
                }
                Quagga.start();
            });

            // Add an event listener for the 'processed' event to handle barcode detection
            Quagga.onProcessed((result) => {
                const drawingCtx = Quagga.canvas.ctx.overlay;
                const drawingCanvas = Quagga.canvas.dom.overlay;

                if (result) {
                    if (result.boxes) {
                        drawingCtx.clearRect(0, 0, parseInt(drawingCanvas.getAttribute("width")), parseInt(drawingCanvas.getAttribute("height")));
                        result.boxes.filter((box) => {
                            return box !== result.box;
                        }).forEach((box) => {
                            Quagga.ImageDebug.drawPath(box, {
                                x: 0,
                                y: 1
                            }, drawingCtx, {
                                color: "green",
                                lineWidth: 2
                            });
                        });
                    }

                    if (result.box) {
                        Quagga.ImageDebug.drawPath(result.box, {
                            x: 0,
                            y: 1
                        }, drawingCtx, {
                            color: "blue",
                            lineWidth: 2
                        });
                    }

                    if (result.codeResult && result.codeResult.code) {
                        barcodeInput.value = result.codeResult.code;
                        Quagga.stop();
                    }
                }
            });

            // Start the barcode scanner
            Quagga.start();
        });
    </script>
</body>

</html>