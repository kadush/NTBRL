<?php
include("Asidebar.php");
require_once('../connection/db.php');
$FacID = $_SESSION['mfl'];
$currentyear = date('Y');


$dt = date("Y-m-d H:i:s");
$day = date("d");
$month = date("m");
$mwak = date("Y");

?>

<body>
    <div class="main-content" style="margin-top: -1%">
        <?php include("Aheader.php");     ?>
        <hr />
        <center>
            <div id="overlay">
                <img src="../assets/neon/neon-x/assets/images/loader-1.gif">
            </div>
        </center>
        <div id="result"></div>
        <!-- Footer -->

    </div>

    <script src="../assets/neon/neon-x/assets/js/gsap/main-gsap.js" id="script-resource-1"></script>
    <script src="../assets/neon/neon-x/assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js" id="script-resource-2"></script>
    <script src="../assets/neon/neon-x/assets/js/bootstrap.min.js" id="script-resource-3"></script>
    <script src="../assets/neon/neon-x/assets/js/joinable.js" id="script-resource-4"></script>
    <script src="../assets/neon/neon-x/assets/js/resizeable.js" id="script-resource-5"></script>
    <script src="../assets/neon/neon-x/assets/js/neon-api.js" id="script-resource-6"></script>
    <script src="../assets/neon/neon-x/assets/js/jquery.dataTables.min.js" id="script-resource-7"></script>
    <script src="../assets/neon/neon-x/assets/js/dataTables.bootstrap.js" id="script-resource-8"></script>
    <script src="../assets/neon/neon-x/assets/js/select2/select2.min.js" id="script-resource-9"></script>
    <script src="../assets/neon/neon-x/assets/js/neon-chat.js" id="script-resource-10"></script>
    <script src="../assets/neon/neon-x/assets/js/neon-custom.js" id="script-resource-11"></script>
    <script src="../assets/neon/neon-x/assets/js/neon-demo.js" id="script-resource-12"></script>
    <script type="text/javascript">
        function FungetID() {

            // alert('load');
            $('#overlay').fadeIn();
            jQuery.ajax({
                type: "POST",
                url: "kila.php",

                success: function(data) {
                    $('#result').html(data);
                }
            });
            $('#overlay').fadeOut(5000);

        }

        window.onload = FungetID();
    </script>
    <footer class="main">

        <div class="pull-right">
            <?php
            include 'footer.php';
            ?>
        </div>

    </footer>
</body>

</html>