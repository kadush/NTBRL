<?php
require_once("../connection/db.php");
error_reporting(0);
$query = "SELECT * FROM drs_participants where drs_lab_bc='$_POST[escnumb]'";
$rs = mysqli_query($dbConn, $query) or die(mysqli_error($dbConn));
$rows = mysqli_fetch_assoc($rs);
$total = mysqli_num_rows($rs);

if ($total == 0) { //if no number found

	$sql = "UPDATE `drs_participants` SET drs_lab_bc='$_POST[escnumb]' WHERE participant_id='$_POST[rid]'";

	$retval = mysqli_query($dbConn, $sql);

	if (!$retval) {
		echo "0";
	} else {
		echo "1";
	}
} else //if number found
{
	echo "2";
}
