<?php
include("Asidebar.php");

//include('includes/functions.php');
$facilitycode = $_SESSION['mfl']; //set facility mflcode from session upon login

//echo $_SESSION['cat'];
if ($facilitycode == '') {
    header("location:../includes/logout.php");
} else {


    $query_rssample = "SELECT * FROM drs_participants WHERE dispatched='0'  and spoke_mfl='$facilitycode'"; //and cond='0'
    $rssample = mysqli_query($dbConn, $query_rssample) or die(mysqli_error($dbConn));
    $row_rssample = mysqli_fetch_assoc($rssample);
    $total = mysqli_num_rows($rssample);
}

?>
<div class="page-container" style="padding-left: 35px !important">
    <?php include("Aheader.php"); ?>
    <hr />
    <!-- <div class="main-content" style="margin-top: -1%">
         -->

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-gradient" data-collapsed="0">

                <div class="panel-heading">
                    <div class="panel-title">
                        All Survey Participants - Awaiting Dispatch
                    </div>

                    <div class="panel-options">
                        <span class="tools pull-right" style="vertical-align: top">
                            <button name="verivyBTN" id="verivyBTN" class="btn btn-success" type="button" onclick="updateItem()">
                                <font color="ffff"><i class="fa fa-check"></i> Dispatch to CRL</font>
                            </button>
                        </span>
                    </div>
                </div>

                <div class="panel-body">

                    <table class="table table-bordered datatable" id="table-1">
                        <thead>
                            <tr>
                                <th>##</th>
                                <th>DRS No</th>
                                <th>BarCode </th>
                                <th>Patient Name</th>
                                <th>Age </th>
                                <th>Gender</th>
                              
                                <th>Date of Enrolled</th>
                                <th>Actions</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php

                            if ($total == 0) {
                                # code...
                            } else {

                                do {
                                    $recid = $row_rssample['participant_id'];
                                    if ($row_rssample['dispatched'] == '1') {
                                        $row_rssample['dispatched'] = 'Transported to hub';
                                        $link = '';
                                    } else {
                                        $row_rssample['dispatched'] = 'Awaiting rider collection';
                                        $link = '<a href="drs_editpat.php?id=' . $row_rssample['participant_id'] . '"><img src="../assets/img/icons/edit.png" height="20" alt="Edit" title="Edit Patient Details "/>Edit</a>';
                                    }

                                    if ($row_rssample['drs_lab_bc'] == '') {
                                        $drs_lab_bc = '<a data-toggle="modal" href="#aCN_' . $recid . '"><i class="entypo-plus-circled"></i></a>';
                                        $check = '<div class="checkbox">
                                                        <label>
                                                            <input readonly type="checkbox" name="verify[]" id="' . $row_rssample['participant_id'] . '" 
                                                        </label>
                                                    </div>';
                                    } else {
                                        $drs_lab_bc = $row_rssample['drs_lab_bc'] . '<a data-toggle="modal" href="#aCN_' . $recid . '"><i class="entypo-pencil"></i></a>';
                                        $check = '<div class="checkbox">
                                                    <label>
                                                        <input type="checkbox" name="verify[]" id="' . $row_rssample['participant_id'] . '" 
                                                    </label>
                                                </div>';
                                    }


                            ?>
                                    <tr class="odd gradeX">
                                        <td> <?php echo $check; ?></td>
                                        <td> <?php echo $row_rssample['drs_no']; ?></td>
                                        <td> <?php echo $drs_lab_bc; ?></td>
                                        <td> <?php echo $row_rssample['fullname']; ?></td>
                                        <td> <?php echo $row_rssample['age']; ?></td>
                                        <td> <?php echo $row_rssample['gender']; ?></td>
                                       
                                        <td> <?php echo $row_rssample['date_enrolled']; ?></td>
                                        <td>
                                            <!-- <a title="View Full Profile" class="btn btn-info btn-sm btn-icon icon-left" data-toggle="modal" data-target="#pi_<?php echo $row_rssample['participant_id']; ?>">
                                                <i class="entypo-info"></i>                                               
                                            </a> -->
                                            <?php echo $link; ?>
                                        </td>
                                    </tr>
                                    <!-- modal update barcode -->
                                    <div class="modal fade custom-width" id="aCN_<?php echo $recid; ?>">
                                        <div class="modal-dialog" style="width: 300px !important;">
                                            <div class="modal-content">

                                                <div class="modal-header"> <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                    <h4 class="modal-title">Add BarCode Number</h4>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <form name="UPCN_<?php echo $recid; ?>" id="UPCN_<?php echo $recid; ?>">
                                                            <div class="col-md-7">
                                                                <div class="form-group"> <label for="field-1" class="control-label">BarCode Number</label>
                                                                    <input type="text" required id="escnumb" name="escnumb" data-validate="required" class="form-control" value="DRS_LAB_" autocomplete="off">
                                                                    <input type="hidden" required id="rid" name="rid" value="<?php echo $recid; ?>">
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" onclick="updateBC(<?php echo $recid; ?>)" class="btn btn-info">Update Barcode</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    <!-- Modal -->
                                    <div class="modal fade" id="11" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                    <h4 class="modal-title" id="myModalLabel">Patient Information</h4>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="col-md-4">
                                                        <label for="field1">Lab No: </label> <?php echo $row_rssample['ln']; ?>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label for="field1">Full Name: </label>
                                                        <?php echo $row_rssample['fullname']; ?>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label>Age: </label><?php echo $row_rssample['age']; ?>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label>Gender: </label><?php echo $row_rssample['gender']; ?>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label>Mobile No: </label><?php echo $row_rssample['mobile']; ?>
                                                    </div>
                                                    <div class="col-md-4"><label for="field3">Physical address: </label>
                                                        <?php echo $row_rssample['address']; ?>
                                                    </div>

                                                    <div class="col-md-4"><label for="field3">Clinician Name: </label>
                                                        <?php echo $row_rssample['c_name']; ?>
                                                    </div>

                                                    <div class="col-md-4"><label for="field3">Date of collection: </label>
                                                        <?php echo $row_rssample['coldate']; ?>
                                                    </div>
                                                </div>

                                            </div>


                                        </div>
                                    </div>

                                    <!-- Modal PI-->
                                    <div class="modal fade custom-width" id="pi_<?php echo $row_rssample['participant_id']; ?>">
                                        <div class="modal-dialog" style="width: 96%">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                    <h4 class="modal-title" id="myModalLabel">Patient Information</h4>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="col-md-4">
                                                        <label for="field1">Lab No: </label> <?php echo $row_rssample['ln']; ?>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label for="field1">Full Name: </label>
                                                        <?php echo $row_rssample['fullname']; ?>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label>Age: </label><?php echo $row_rssample['age']; ?>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label>Gender: </label><?php echo $row_rssample['gender']; ?>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label>Mobile No: </label><?php echo $row_rssample['mobile']; ?>
                                                    </div>
                                                    <div class="col-md-4"><label for="field3">Physical address: </label>
                                                        <?php echo $row_rssample['address']; ?>
                                                    </div>

                                                    <div class="col-md-4"><label for="field3">Clinician Name: </label>
                                                        <?php echo $row_rssample['c_name']; ?>
                                                    </div>

                                                    <div class="col-md-4"><label for="field3">Date of collection: </label>
                                                        <?php echo $row_rssample['coldate']; ?>
                                                    </div>
                                                </div>
                                                <div class="modal-footer"> <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> <button type="button" class="btn btn-info">Save changes</button> </div>
                                            </div>
                                        </div>
                                    </div>

                            <?php } while ($row_rssample = mysqli_fetch_assoc($rssample));
                            } ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="modal fade custom-width" id="modal-77">
            <div class="modal-dialog" style="max-width: 46%">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Sample Dispatch
                        </h4>
                    </div>
                    <div class="modal-body">
                        <form name="save_rider" id="save_rider" class="validate" method="post" role="form">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Are you sure you want to dispatch the sample(s)</label>
                                    <div class="input-group">
                                        <input type="hidden" id="datecol" name="datecol" data-validate="required">

                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="samp" name="samp">
                            <div class="clear"></div>
                            <br>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button class="btn btn-info" name="btnUpload" id="btnUpload" type="button" onClick="update()">Dispatch to Hub</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer -->
        <footer class="main">

            <div class="pull-right">
                <?php
                include 'footer.php';
                ?>
            </div>

        </footer>

        <!-- Modal 3 (Custom Width)-->
        <div class="modal fade custom-width" id="modal-10">
            <div class="modal-dialog" style="width: 96%">
                <div class="modal-content">
                    <div class="modal-header"> <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h4 class="modal-title">Full width</h4>
                    </div>
                    <div class="modal-body">
                        Its about 100%
                    </div>
                    <div class="modal-footer"> <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> <button type="button" class="btn btn-info">Save changes</button> </div>
                </div>
            </div>
        </div>

    </div>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $("#table-1").dataTable({
                "sPaginationType": "bootstrap",
                "aLengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                "bStateSave": true
            });

            $(".dataTables_wrapper select").select2({
                minimumResultsForSearch: -1
            });

            $('#escnumb').keyup(function() {
                this.value = this.value.toUpperCase();
            });
        });
    </script>
    <link rel="stylesheet" href="../assets/neon/neon-x/assets/js/select2/select2-bootstrap.css" id="style-resource-1">
    <link rel="stylesheet" href="../assets/neon/neon-x/assets/js/select2/select2.css" id="style-resource-2">
    <script src="../assets/neon/neon-x/assets/js/bootstrap-tagsinput.min.js" id="script-resource-8"></script>
    <script src="../assets/neon/neon-x/assets/js/jquery.inputmask.bundle.min.js" id="script-resource-7"></script>
    <script src="../assets/neon/neon-x/assets/js/gsap/main-gsap.js" id="script-resource-1"></script>
    <script src="../assets/neon/neon-x/assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js" id="script-resource-2"></script>
    <script src="../assets/neon/neon-x/assets/js/bootstrap.min.js" id="script-resource-3"></script>
    <script src="../assets/neon/neon-x/assets/js/joinable.js" id="script-resource-4"></script>
    <script src="../assets/neon/neon-x/assets/js/resizeable.js" id="script-resource-5"></script>
    <script src="../assets/neon/neon-x/assets/js/neon-api.js" id="script-resource-6"></script>
    <script src="../assets/neon/neon-x/assets/js/jquery.dataTables.min.js" id="script-resource-7"></script>
    <script src="../assets/neon/neon-x/assets/js/dataTables.bootstrap.js" id="script-resource-8"></script>
    <script src="../assets/neon/neon-x/assets/js/select2/select2.min.js" id="script-resource-9"></script>
    <script src="../assets/neon/neon-x/assets/js/neon-chat.js" id="script-resource-10"></script>
    <script src="../assets/neon/neon-x/assets/js/neon-custom.js" id="script-resource-11"></script>
    <script src="../assets/neon/neon-x/assets/js/neon-demo.js" id="script-resource-12"></script>
    <script src="../assets/neon/neon-x/assets/js/toastr.js" id="script-resource-7"></script>
    <script src="../assets/neon/neon-x/assets/js/bootstrap-datepicker.js" id="script-resource-11"></script>
    <script type="text/javascript">
        function updateItem() {

            var notChecked = [],
                checked = [];
            $(":checkbox").each(function() {
                if (this.checked) {
                    checked.push(this.id);
                } else {
                    notChecked.push(this.id);
                }
            });

            var num = checked.length;
            //alert(num);

            if (num == 0) {
                alert('Kindly select atleast one sample to dispatch');
            } else {

                $('#samples').html(checked);
                document.getElementById('samp').value = checked;
                // Create a new Date object which represents the current date and time
                var currentDate = new Date();
                // You can then use various methods of the Date object to get specific parts of the date
                var year = currentDate.getFullYear();
                // Get the month and pad it with leading zero if necessary
                var month = ('0' + (currentDate.getMonth() + 1)).slice(-2);
                // Get the day and pad it with leading zero if necessary
                var day = ('0' + currentDate.getDate()).slice(-2);
                // You can format the date however you want
                var formattedDate = year + '-' + month + '-' + day;
                document.getElementById('datecol').value = formattedDate;
                showAjaxModal(checked);
            }

        }
    </script>
    <script type="text/javascript">
        function showAjaxModal(s) {


            jQuery('#modal-77').modal('show', {
                backdrop: 'static'
            });
            // jQuery.ajax({
            //     //url: "../assets/neon/neon-x/data/ajax-content.txt",
            //     success: function(response) {
            //         jQuery('#modal-77 .modal-body').html(response);
            //     }
            // });

            //alert(s);
            //exit;
            // jQuery.ajax({
            //     type: "POST",
            //     url: "fac.php",
            //     data: 'id=' + s,
            //     cache: false,
            //     dataType: "json",
            //     success: function(data) {
            //         $.each(data, function(i, v) {
            //             $("#" + i).val(v)

            //         });
            //     }
            // });
        }

        function updateBC(a) {

            $.ajax({

                type: "POST",
                url: "updateBC.php",
                data: $("#UPCN_" + a).serialize(),
                cache: false,
                success: function(data) {
                    // alert(data);
                    // exit;
                    if (data == 1) {
                        var opts = {
                            "closeButton": true,
                            "debug": false,
                            "positionClass": "toast-top-right",
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        };

                        toastr.success("Update Successful", "Update Response", opts);

                        //$("#")[0].reset();
                        //$('#delete_' + a).modal('hide');
                        window.setTimeout(function() {
                            location.href = "p_view.php";
                        }, 2000);
                    }
                    if (data == 2) {
                        var opts = {
                            "closeButton": true,
                            "debug": false,
                            "positionClass": "toast-top-right",
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        };

                        toastr.error("Barcode already used. Use a different one", "Update Response", opts);
                    };
                    if (data == 0) {
                        var opts = {
                            "closeButton": true,
                            "debug": false,
                            "positionClass": "toast-top-right",
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        };

                        toastr.error("Update Failed", "Update Response", opts);
                    };

                }

            })
        } // End of  keyup function 

        function update(s) {
            //updateAll(checked,0);
            $.ajax({
                url: 'updateV.php',
                type: 'POST',
                data: $("#save_rider").serialize(),
                dataType: "json",
                cache: false,
                success: function(data) {

                    // alert(data);
                    // exit;
                    if (data == 1) {
                        var opts = {
                            "closeButton": true,
                            "debug": false,
                            "positionClass": "toast-top-right",
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        };

                        toastr.success("Update Successful", "Update Response", opts);

                        //$("#")[0].reset();
                        //$('#delete_' + a).modal('hide');
                        window.setTimeout(function() {
                            location.href = "p_view.php";
                        }, 2000);
                    }

                    if (data == 0) {
                        var opts = {
                            "closeButton": true,
                            "debug": false,
                            "positionClass": "toast-top-right",
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        };

                        toastr.error("Update Failed", "Update Response", opts);
                    };

                }
            })
        }
    </script>

    </body>

    </html>