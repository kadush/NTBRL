<?php
session_start();
require_once('../connection/db.php');
error_reporting(0);

$hub = $_SESSION['hub'];
$facilitycode = $_SESSION['mfl'];
$email = $_SESSION['email'];
$phone = $_SESSION['phone'];
$user = $_SESSION['nm'];

//echo $_SESSION['cat'];
if ($facilitycode == '') {
	header("location:../includes/logout.php");
} else {

	/* check level of user(to avoid url injection)) or $_SESSION['cat'] != 2  or $_SESSION['cat'] != 3 */
	if ($_SESSION['nm'] == "") {
		//redirect to login page
		//echo 'wrong';
		header("location:../login");
	}

	if (isset($_SESSION['mfl'])) {
		$FacID = $_SESSION['mfl']; //set facility mflcode from session upon login
		// $q = "SELECT 
		// (
		// SELECT count(ID) FROM samplescm WHERE MONTH(tym)=MONTH(CURRENT_TIMESTAMP) and  YEAR(tym)=YEAR(CURRENT_TIMESTAMP) and  cond=1 and Refacility='$FacID'
		// )AS complete, 
		// (
		// SELECT count(ID) FROM samplescm WHERE MONTH(tym)=MONTH(CURRENT_TIMESTAMP) and  YEAR(tym)=YEAR(CURRENT_TIMESTAMP) and (Test_Result='Positive' or Test_Result='Trace') and cond=1 and Refacility='$FacID'
		// )AS mtb, 
		// (
		// SELECT count(ID) FROM samplescm WHERE MONTH(tym)=MONTH(CURRENT_TIMESTAMP) and  YEAR(tym)=YEAR(CURRENT_TIMESTAMP) and mtbRif='Positive' and cond=1 and Refacility ='$FacID'
		// )AS rif, 
		// (
		//   SELECT count(ID) FROM samplescm WHERE MONTH(tym)=MONTH(CURRENT_TIMESTAMP) and  YEAR(tym)=YEAR(CURRENT_TIMESTAMP) and dispatched=1 and Refacility='$FacID'
		// )AS dispatched,
		// (
		//   SELECT count(ID) FROM samplescm WHERE MONTH(tym)=MONTH(CURRENT_TIMESTAMP) and  YEAR(tym)=YEAR(CURRENT_TIMESTAMP) and cond=2 and Refacility='$FacID'
		// )AS notdispatched,
		// (
		//  SELECT count(ID) FROM samplescm WHERE MONTH(tym)=MONTH(CURRENT_TIMESTAMP) and  YEAR(tym)=YEAR(CURRENT_TIMESTAMP) and Refacility='$FacID'
		// )AS totalcol";
		// $r = mysqli_query($dbConn, $q) or die(mysqli_error($dbConn));
		// $row = mysqli_fetch_assoc($r);
		// $complete = $row['complete'];
		// $totalcol = $row['totalcol'];
		// $dispatched = $row['dispatched'];
		// $notdispatched = $row['notdispatched'];
		// $mtb = $row['mtb'];
		// $rif = $row['rif'];

	}

	
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><![endif]-->

	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="description" content="Neon Admin Panel" />
	<meta name="author" content="Laborator.co" />

	<title>TIBULims|Spoke</title>
	<link rel="icon" href="../assets/img/favicon.ico" type="image/x-icon" />
	<link rel="stylesheet" href="../assets/neon/neon-x/assets/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css" id="style-resource-1">
	<link rel="stylesheet" href="../assets/neon/neon-x/assets/css/font-icons/entypo/css/entypo.css" id="style-resource-2">
	<link rel="stylesheet" href="../assets/neon/neon-x/assets/css/font-icons/entypo/css/animation.css" id="style-resource-3">
	<link rel="stylesheet" href="../assets/neon/neon-x/assets/css/neon.css" id="style-resource-5">
	<link rel="stylesheet" href="../assets/neon/neon-x/assets/css/custom.css" id="style-resource-6">
	<link rel="stylesheet" type="text/css" href="../assets/js/jquery-tags-input/jquery.tagsinput.css" />
	<script src="../assets/neon/neon-x/assets/js/jquery-1.10.2.min.js"></script>
	<!-- <link rel="stylesheet" href="../FusionCharts/Contents/Style.css" type="text/css" />
    <script language="JavaScript" src="../FusionMaps/JSClass/FusionMaps.js"></script>
    <script language="JavaScript" src="../FusionCharts/FusionCharts.js"></script> -->

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	  <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
	<![endif]-->

	<!-- TS1387506872: Neon - Responsive Admin Template created by Laborator -->
</head>

<body class="page-body page-fade">

	<div class="page-container">

		<div class="sidebar-menu">

			<header class="logo-env">

				<!-- logo -->
				<div class="logo">
					<a href="index.php">
						<img src="../assets/img/tibulimsh.jpg" class="img-responsive" alt="Responsive image" style="width: 170px;height: 50px" />
					</a>
				</div>

				<!-- logo collapse icon -->
				<div class="sidebar-collapse">
					<a href="#" class="sidebar-collapse-icon with-animation">
						<!-- add class "with-animation" if you want sidebar to have animation during expanding/collapsing transition -->
						<i class="entypo-menu"></i>
					</a>
				</div>


				<!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
				<div class="sidebar-mobile-menu visible-xs">
					<a href="#" class="with-animation">
						<!-- add class "with-animation" to support animation -->
						<i class="entypo-menu"></i>
					</a>
				</div>

			</header>

			<ul id="main-menu" class="">

				<li>
					<a href="index.php"><i class="entypo-gauge"></i><span>Dashboard</span></a>

				</li>

				<li>
					<a href="presumptive.php"><i class="entypo-user-add"></i><span>Add Presumptive Case</span></a>
				</li>

				<li>
					<a href="p_view.php"><i class="entypo-docs"></i><span>View Presumptive Cases</span>
						<div id='notdispatched' style="margin-bottom: 20px;max-width: 20px; float: right"><span class="badge badge-warning" style="float: right;"></span></div>
					</a>
				</li>
				<li>
					<a href="dispatched.php"><i class="entypo-upload"></i><span>Dispatched Samples</span>
						<div id='dispatched' style="margin-bottom: 20px;max-width: 20px; float: right"><span class="badge badge-success" style="float: right;"></span></div>
					</a>
				</li>

				<li>
					<a href="changePass.php"><i class="entypo-user"></i><span>Change Password</span></a>
				</li>
			</ul>


		</div>