<?php
session_start();
require_once('../connection/db.php');
error_reporting(0);
$FacID = $_SESSION['mfl'];

$device = $_POST['device'];

if ($device == '1') {
	$datatable = 'samplescm';
} else {
	$datatable = 'sample1';
}


$currentmonth = date("m");
$year = date("Y");
$previousmonth = date("m") - 1;


if ($currentmonth == 1) {
	$year = date("Y");
	$previousmonth = 12;
	$previousyear = date("Y") - 1;
} else {
	$previousmonth = date("m") - 1;
	$previousyear = date("Y");
}

$q = "SELECT 
		count(*) as enrolled,
		sum( CASE WHEN dispatched =  '1'  THEN 1 ELSE 0 END ) AS collected,
		sum( CASE WHEN dispatched =  '1'  THEN 1 ELSE 0 END) as dispatched,
		sum( CASE WHEN cond =  '1'  THEN 1 ELSE 0 END) as logged
		
		FROM drs_participants WHERE  spoke_mfl='$FacID'"; //MONTH(date_enrolled)=MONTH(CURRENT_TIMESTAMP) and  YEAR(date_enrolled)=YEAR(CURRENT_TIMESTAMP) and

$r = mysqli_query($dbConn, $q) or die(mysqli_error($dbConn));
$row = mysqli_fetch_assoc($r);
do {

	$totalcol =  (int)$row['enrolled'];
	$dispatched = (int) $row['dispatched'];
	$collected = (int) $row['collected'];
	$logged = (int) $row['logged'];
	$res .= '<div class="row">
				<div class="col-sm-3">

					<div class="tile-stats tile-blue">
						<div class="icon"><i class="entypo-calendar"></i></div>
						<div class="num" data-start="0" data-end="' . $totalcol . '" data-postfix="" data-duration="1500" data-delay="1200">' . $totalcol . '</div>

						<h3>Total Enrolled</h3>
						<p>Participants.</p>
					</div>

				</div>
				<div class="col-sm-3">

					<div class="tile-stats tile-green">
						<div class="icon"><i class="entypo-chart-bar"></i></div>
						<div class="num" data-start="0" data-end="' . $collected . '" data-postfix="" data-duration="1500" data-delay="600">' . $collected . '</div>

						<h3>Samples Collected</h3>
						<p>this month.</p>
					</div>

				</div>

				<div class="col-sm-3">

					<div class="tile-stats tile-aqua">
						<div class="icon"><i class="entypo-basket"></i></div>
						<div class="num" data-start="0" data-end="' . $dispatched . '" data-postfix="" data-duration="1500" data-delay="0">' . $dispatched . '</div>

						<h3>Samples dispatched</h3>
						<p>to CRL.</p>
					</div>

				</div>

				<div class="col-sm-3">

					<div class="tile-stats tile-red">
						<div class="icon"><i class="entypo-volume"></i></div>
						<div class="num" data-start="0" data-end="' . $logged . '" data-postfix="" data-duration="1500" data-delay="1800">' . $logged . '</div>

						<h3>Samples Received </h3>
						<p>at CRL.</p>
					</div>

				</div>
</div>';
} while ($row = mysqli_fetch_assoc($query));
echo $res;

mysqli_close($dbConn);
