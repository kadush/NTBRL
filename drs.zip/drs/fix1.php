<?php
require_once('../connection/db.php');
session_start();
if (isset($_POST['id'])) {
  $searchno = $_POST['id'];

  $table = $_SESSION['table'];
  $genesite = $_SESSION['genesite'];

  if ($genesite == '1') {
    $DX = "GeneXpert";
  } else {
    $DX = "TrueNat";
  }


  $sql = "SELECT fnname as fname,mname,lname,id_no,dob,age,gender,address as residence, Test_Result as MTB_Result, mtbRif as RIF_Result, mobile as p_no, End_Time as date_of_diagnosis,h_status as hivStatus FROM $table WHERE ID='$searchno'";
  $rsFinC = mysqli_query($dbConn, $sql) or die(mysqli_error($dbConn));
  $row_rsFinC = mysqli_fetch_assoc($rsFinC);


  if (mysqli_num_rows($rsFinC) == 0) {
  } else {

    $row_rsFinC["initial_DX"] = "$DX" ;

    echo json_encode($row_rsFinC);
  }
  mysqli_close($dbConn);
}
