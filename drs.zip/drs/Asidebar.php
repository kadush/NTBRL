<?php
session_start();
require_once('../connection/db.php');
error_reporting(0);
if ($_SESSION['nm'] == "") { //or $_SESSION['cat'] != 3
	//redirect to login page
	//echo 'wrong';
	header("location:../index.php");
}
//include('includes/functions.php');
$facilitycode = $_SESSION['mfl']; //set facility mflcode from session upon login
$rname = $_SESSION['region'];
$cname = $_SESSION['county']; //name of county
$scname = $_SESSION['sub_county']; //name of county
$fcname = $_SESSION['facility']; //name of county
$genesite = $_SESSION['genesite']; //name of county
$truesite = $_SESSION['truenat']; //name of county
$stoolsite = $_SESSION['stool'];

if ($genesite == '1' && $truesite == '1') {
	$text = 'Genesite & Truenat Site';
	$option = '<option value="1">GeneXpert</option><option value="2">TrueNat</option>';
} elseif ($genesite == '1' && $truesite == '0') {
	$text = 'Genesite Site';
	$option = '<option value="1">GeneXpert</option>';
	$_SESSION['table']='sample1 ';
} elseif ($genesite == '0' && $truesite == '1') {
	$text = 'Truenat Site';
	$option = '<option value="2">Truenat</option>';
	$_SESSION['table']='sampletn ';
} else {
	$text = 'Not Found';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><![endif]-->

	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="description" content="Neon Admin Panel" />
	<meta name="author" content="Laborator.co" />

	<title>TIBULims|DRS</title>
	<link rel="icon" href="../assets/img/favicon.ico" type="image/x-icon" />
	<link rel="stylesheet" href="../assets/neon/neon-x/assets/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css" id="style-resource-1">
	<link rel="stylesheet" href="../assets/neon/neon-x/assets/css/font-icons/entypo/css/entypo.css" id="style-resource-2">
	<link rel="stylesheet" href="../assets/neon/neon-x/assets/css/font-icons/entypo/css/animation.css" id="style-resource-3">
	<link rel="stylesheet" href="../assets/neon/neon-x/assets/css/neon.css" id="style-resource-5">
	<link rel="stylesheet" href="../assets/neon/neon-x/assets/css/custom.css" id="style-resource-6">
	<link rel="stylesheet" type="text/css" href="../assets/js/jquery-tags-input/jquery.tagsinput.css" />
	<script src="../assets/neon/neon-x/assets/js/jquery-1.10.2.min.js"></script>
	<!-- <link rel="stylesheet" href="../FusionCharts/Contents/Style.css" type="text/css" />
    <script language="JavaScript" src="../FusionMaps/JSClass/FusionMaps.js"></script>
    <script language="JavaScript" src="../FusionCharts/FusionCharts.js"></script> -->

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	  <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
	<![endif]-->

	<!-- TS1387506872: Neon - Responsive Admin Template created by Laborator -->
</head>

<body class="page-body page-fade">

	<div class="page-container">

		<div class="sidebar-menu">

			<header class="logo-env">

				<!-- logo -->
				<div class="logo">
					<a href="index.php">
						<img src="../assets/img/tibulimsh.jpg" class="img-responsive" alt="Responsive image" style="width: 170px;height: 50px" />
					</a>
				</div>

				<!-- logo collapse icon -->
				<div class="sidebar-collapse">
					<a href="#" class="sidebar-collapse-icon with-animation">
						<!-- add class "with-animation" if you want sidebar to have animation during expanding/collapsing transition -->
						<i class="entypo-menu"></i>
					</a>
				</div>


				<!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
				<div class="sidebar-mobile-menu visible-xs">
					<a href="#" class="with-animation">
						<!-- add class "with-animation" to support animation -->
						<i class="entypo-menu"></i>
					</a>
				</div>

			</header>

			<ul id="main-menu" class="">

				<li>
					<a href="index.php"><i class="entypo-gauge"></i><span>Dashboard</span></a>

				</li>
				<li>
					<a href="drsPot.php"><i class="entypo-user-add"></i><span>Eligible DRS Participants</span></a>
				</li>
				<li>
					<a href="drs_newpat.php"><i class="entypo-user-add"></i><span>Add Survey Participant</span></a>
				</li>

				<li>
					<a href="p_view.php"><i class="entypo-docs"></i><span>View Survey Participant</span>
						<div id='notdispatchedD' style="margin-bottom: 20px;max-width: 20px; float: right"></div>
					</a>
				</li>
				<li>
					<a href="dispatched.php"><i class="entypo-upload"></i><span>Dispatched Samples</span>
						<div id='dispatchedD' style="margin-bottom: 20px;max-width: 20px; float: right"></div>
					</a>
				</li>

				<li>
					<a href="changePass.php"><i class="entypo-user"></i><span>Change Password</span></a>
				</li>
			</ul>


		</div>