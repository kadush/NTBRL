
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code Scanner</title>
</head>
<body>
    <h1>QR Code Scanner</h1>
    <video id="qr-video" width="100%" autoplay playsinline></video>
    <input type="text" id="qr-result" placeholder="QR Code Result" readonly>
    <script src="qrscanner.js"></script>
    <script src="instascan.min.js"></script>
</body>
</html>
