<?php
error_reporting(0);
include("../connection/db.php");
include("functions.php");
$ID = $_POST['samp'];
$date = $_POST['datecol'];

if ($date == '') {
	$arr = array('message' => 'Select Date to continue', 'title' => 'Update Response');
	echo json_encode($arr);
	exit;
} else {
	$query = "SELECT batch_no as num FROM drs_participants where batch_no!='' and dispatched='1' ORDER by editTym DESC LIMIT 1";
	$rs = mysqli_query($dbConn, $query) or die(mysqli_error($dbConn));
	$rows = mysqli_fetch_assoc($rs);
	$no = $rows['num']; //no

	if (mysqli_affected_rows($dbConn, $rs) == 0) { //if number found

		$num = substr($no, -5); //get last part of the number e.g if no=190715_13023_00001 we get the 00001
		$namba = str_pad($num + 1, 5, 0, STR_PAD_LEFT); //then increment by 1 to get 00002
	} else //if no number found
	{
		$num = rand(1, 1);
		for ($i = 1; $i <= $num; $i++) {
			$namba = str_pad($i, 5, '0', STR_PAD_LEFT); //create the number starting with 00001
		}
	}

	$batch = "BTCH" . "_" . $namba;
	$variable = "$ID";
	// Split the text into an array using the comma as the delimiter
	$array = explode(',', $variable);

	// Loop through the items in the array
	foreach ($array as $item) {
		//echo $item . "<br>";

		$sql = "UPDATE `drs_participants` SET dispatched='1', cond='0', batch_no='$batch',dispatch_date='$date' WHERE participant_id IN($item)";
		$rsFinC = mysqli_query($dbConn, $sql) or die(mysqli_error($dbConn));

		if (!$rsFinC) {
			// $arr = array('message' => 'Update Failed', 'title' => 'Update Response');
			// echo json_encode($arr);
			echo '0';
		} else {
			// $arr = array('message' => 'Update Successfully done', 'title' => 'Update Response');
			// echo json_encode($arr);
			// $newrec = mysqli_insert_id($dbConn);
			
			postToLabware($item);
			echo '1';
		}
	}
}
