<?php
require_once('../connection/db.php'); 

if (isset($_POST['id'])){
$searchno=$_POST['id'];

$sql= "SELECT * FROM drs_participants WHERE participant_id='$searchno'";
$rsFinC = mysqli_query($dbConn,$sql) or die(mysqli_error($dbConn));
$row_rsFinC = mysqli_fetch_assoc($rsFinC);


if( mysqli_num_rows($rsFinC)==0)
{
	
} 
else
{
  echo json_encode($row_rsFinC);
}
mysqli_close($dbConn);
}
?>