<?php

include("Asidebar.php");
require_once('../connection/db.php');

$facilitycode = $_SESSION['mfl'];
$facilityname = $_SESSION['facility'];
if (isset($_POST["btnsave"])) {


	$newpassword = md5($_POST['password']);
	$repeatnewpassword = md5($_POST['password1']);
	$username = $_POST['username'];
	if ($newpassword == $repeatnewpassword) {

		$sql1 = "select * FROM tr_user where username='$username' LIMIT 1";

		$samp = mysqli_query($dbConn, $sql1);
		$sampContent = mysqli_fetch_row($samp);
		//checks if username exist
		if (mysqli_num_rows($samp) > 0) {
			$errormsg = "Username already exists";
		} else {
			$sql = "INSERT INTO tr_user (name,category,mfl,facility,email,mobile,username,password,st)
			VALUES('$_POST[name]',
			'3',
			'$facilitycode',
			'$facilityname',
			'$_POST[email]',
			'$_POST[no]',
			'$username',
			'$newpassword','1')";

			//exit;
			$retval = mysqli_query($dbConn, $sql);
			if (!$retval) {
				$errormsg = "Could not enter data.Try Again";
			} else {
				$suceessmsg = 'User successfully added';
				
				
			}
		}
	} else {
		$errormsg = "Passwords do not match";
	}
}
//mysqli_close($dbConn);
?>

<div class="main-content" style="margin-top: -1%">
	<?php include("Aheader.php");	 ?>


	<hr />
	<div class="row">
		<div class="col-md-12">

			<div class="panel panel-gradient" data-collapsed="0">

				<div class="panel-heading">
					<div class="panel-title">
						Add New user
					</div>

					<div class="panel-options">

					</div>
				</div>

				<div class="panel-body">

					<?php if ($errormsg != "") {
						?>
						<div class="alert alert-danger" style="text-align: center;"><?php

																									echo  ' <font size="1.2">' . $errormsg . ' </font>';
																									?></div>
					<?php } ?>
					<?php if ($suceessmsg != "") {
						?>
						<div class="alert alert-success" style="text-align: center;"><?php

																				echo   $suceessmsg

																				?></div>
					<?php } ?>

					<form name="save" method="post">
						<table class="table table-striped" style="width: auto;">

							<tr valign="center">
								<th style="text-align: center;">
									<font size="1.4">Full Name</font>
								</th>
								<td style="text-align: center;"><input type="text" class="form-control" autocomplete="off" name="name" id="name" size="30" required /> </td>
								<td colspan="2"><label class="">For Fullname: Kindly indicate more than one name.</label></td>
							</tr>
							<tr>
								<th colspan='4'>&nbsp;</th>
							</tr>

							<th style="text-align: center;" colspan='1'>
								<font size="1.4">Email:
							</th>
							<td><input type="text" class="form-control" id="email" name="email" data-validate="email" required /></td>
							<th style="text-align: center;" colspan='1'>
								<font size="1.4">Mobile No:
							</th>
							<td><input type="text" name="no" id="no" class="form-control" /></td>
							</tr>
							<tr>
								<th colspan='4'>&nbsp;</th>
							</tr>
							<tr>
								<th style="text-align: center;" colspan='1'>
									<font size="1.4">Username</font>
								</th>
								<td style="text-align: left;"><input type="text" class="form-control" autocomplete="off" name="username" id="username" size="25" required autocomplete="off" /></td>
								<td colspan="2"><label class="">For username: If your first name is 'First' and <br /> name is 'Second', Your username should be 'fsecond'</br> word in small letters.</label></td>
							</tr>
							<tr>
								<th colspan='4'>&nbsp;</th>
							</tr>
							<tr>
								<th style="text-align: center;">
									<font size="1.4">Password</font>
								</th>
								<td style="text-align: center;"><input type="password" autocomplete="off" class="form-control" name="password" id="password" required /></td>

								<th style="text-align: center;">
									<font size="1.4">Repeat Password </font>
								</th>
								<td style="text-align: center;"><input type="password" class="form-control" name="password1" id="password1" required /></td>
							</tr>
							<tr>
								<th colspan='4'>&nbsp;</th>
							</tr>
							<tr>

								<td colspan="4">
									<div align="center">
										<button class="btn btn-success btn-icon icon-left" type="submit" name="btnsave">Add User<i class="entypo-user-add"></i></button>
										<input type="reset" name="button2" id="button2" value="Reset" class="btn btn-default" />
									</div>
								</td>
							</tr>
						</table>
						<input type="hidden" name="MM_insert" value="save" />
					</form>

				</div>

			</div>

		</div>
	</div>
	<!-- Footer -->
	<footer class="main">

		<div class="pull-right">
			<?php
			include '../includes/footer.php';
			?>
		</div>

	</footer>
</div>


<link rel="stylesheet" href="../assets/neon/neon-x/assets/js/select2/select2-bootstrap.css" id="style-resource-1">
<link rel="stylesheet" href="../assets/neon/neon-x/assets/js/select2/select2.css" id="style-resource-2">

<script src="../assets/neon/neon-x/assets/js/gsap/main-gsap.js" id="script-resource-1"></script>
<script src="../assets/neon/neon-x/assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js" id="script-resource-2"></script>
<script src="../assets/neon/neon-x/assets/js/bootstrap.min.js" id="script-resource-3"></script>
<script src="../assets/neon/neon-x/assets/js/joinable.js" id="script-resource-4"></script>
<script src="../assets/neon/neon-x/assets/js/resizeable.js" id="script-resource-5"></script>
<script src="../assets/neon/neon-x/assets/js/neon-api.js" id="script-resource-6"></script>
<script src="../assets/neon/neon-x/assets/js/jquery.dataTables.min.js" id="script-resource-7"></script>
<script src="../assets/neon/neon-x/assets/js/dataTables.bootstrap.js" id="script-resource-8"></script>
<script src="../assets/neon/neon-x/assets/js/select2/select2.min.js" id="script-resource-9"></script>
<script src="../assets/neon/neon-x/assets/js/neon-chat.js" id="script-resource-10"></script>
<script src="../assets/neon/neon-x/assets/js/neon-custom.js" id="script-resource-11"></script>
<script src="../assets/neon/neon-x/assets/js/neon-demo.js" id="script-resource-12"></script>


</body>

</html>