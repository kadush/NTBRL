<?php
error_reporting(0);
@require_once('../connection/db.php');
session_start();
$hub = $_SESSION['hub'];
$spoke = $_SESSION['mfl'];
$ID = $_GET['id'];
$query = "SELECT count(participant_id) as ws FROM drs_participants WHERE spoke_mfl='$spoke' and dispatched='0'"; //Refacility ='$ID' and dispatched='0' and cond='2' and cond='2'
//exit;
$rs = mysqli_query($dbConn, $query) or die(mysqli_error($dbConn));
$rows = mysqli_fetch_assoc($rs);
$no = $rows['ws'];

echo '<span class="badge badge-info">' . $no . '</span>';
	   
       	// $table.='<table class="table table-striped"><tr><th  style="text-align:center">User ID</th><th  style="text-align:center">Full Name</th><th  style="text-align:center">Username</th><th  style="text-align:center">Mfl Code</th><th  style="text-align:center">Email</th><th  style="text-align:center">Phone No</th><th  style="text-align:center">Facility Name</th></tr>';
        //echo 'kadush';
