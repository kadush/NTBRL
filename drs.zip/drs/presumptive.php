<?php
include("Asidebar.php");
//session_start();
require_once('../connection/db.php');

$hub = $_SESSION['hub'];
/* query for getting examination required from the reference table */
$query_rsexamination_required = "SELECT examination_required.id, examination_required.type FROM examination_required ORDER BY examination_required.id";
$rsexamination_required = mysqli_query($dbConn, $query_rsexamination_required) or die(mysqli_error($dbConn));
$row_rsexamination_required = mysqli_fetch_assoc($rsexamination_required);
$totalRows_rsexamination_required = mysqli_num_rows($rsexamination_required);
/* to be used in presumptive.php under examination required */
$query_rsST = "SELECT `type` FROM specimen_type ORDER BY id";
$rsST = mysqli_query($dbConn, $query_rsST) or die(mysqli_error($dbConn));
$row_rsST = mysqli_fetch_assoc($rsST);
$totalRows_rsST = mysqli_num_rows($rsST);

/* query for getting the hiv statuses from reference table*/
$query_rshiv_status = "SELECT hiv_status.id, hiv_status.status FROM hiv_status ORDER BY hiv_status.id";
$rshiv_status = mysqli_query($dbConn, $query_rshiv_status) or die(mysqli_error($dbConn));
$row_rshiv_status = mysqli_fetch_assoc($rshiv_status);
$totalRows_rshiv_status = mysqli_num_rows($rshiv_status);
/* to be used in the hiv status under presumptive.php*/

/* query for getting type of patient from the reference table */
$query_rstype_of_patient = "SELECT type_of_patient.id, type_of_patient.type FROM type_of_patient ORDER BY type_of_patient.id";
$rstype_of_patient = mysqli_query($dbConn, $query_rstype_of_patient) or die(mysqli_error($dbConn));
$row_rstype_of_patient = mysqli_fetch_assoc($rstype_of_patient);
$totalRows_rstype_of_patient = mysqli_num_rows($rstype_of_patient);
/* to be used in the patient type under presumptive.php*/
// $sqlCN = "SELECT region,county,sub_county,facility FROM facility_map WHERE `mfl`='$facilitycode'";

// $qCN = mysqli_query($dbConn, $sqlCN) or die(mysqli_error($dbConn));
// $rwCN = mysqli_fetch_assoc($qCN);
// $rname = $rwCN['region']; //name of county
// $cname = mysqli_real_escape_string($dbConn, $rwCN['county']); //name of county
// $scname = mysqli_real_escape_string($dbConn, $rwCN['sub_county']); //name of county
// $ref_fac = mysqli_real_escape_string($dbConn, $rwCN['facility']); //name of county


/* query for getting all facilities in a county which the testing facility is based */
$query_rsfacilitys = "SELECT `mfl` AS CODE,`facility` AS FACILITY FROM `facility_map` WHERE `region` = '$rname'";

$rsfacilitys = mysqli_query($dbConn, $query_rsfacilitys) or die(mysqli_error($dbConn));
$row_rsfacilitys = mysqli_fetch_assoc($rsfacilitys);
$totalRows_rsfacilitys = mysqli_num_rows($rsfacilitys);
/* to be used in the referring facility under presumptive.php */


//getting the last lab No in the database 

if (isset($_POST["btnUpload"])) {

    $receipt_date = date("Y-m-j");

    $p_age = str_replace('_', '', $_POST['p_age']);


    //getting the last lab No in the database 
    $query = "SELECT sample1.lab_no as num FROM sample1 where facility='$hub' and lab_no!='' ORDER by tym DESC LIMIT 1";
    $rs = mysqli_query($dbConn, $query) or die(mysqli_error($dbConn));
    $rows = mysqli_fetch_assoc($rs);
    $no = $rows['num']; //no

    if (mysqli_affected_rows($dbConn, $rs) == 0) { //if number found

        $num = substr($no, -5); //get last part of the number e.g if no=190715_13023_00001 we get the 00001
        $namba = str_pad($num + 1, 5, 0, STR_PAD_LEFT); //then increment by 1 to get 00002
    } else //if no number found
    {
        $num = rand(1, 1);
        for ($i = 1; $i <= $num; $i++) {
            $namba = str_pad($i, 5, '0', STR_PAD_LEFT); //create the number starting with 00001
        }
    }

    $lab_no = date("dmy_") . $hub . "_" . $namba;
    $id_no = $_POST['id_no'];

    //$sqlCN = "SELECT facility FROM facility_map WHERE `mfl`='$hub'";
    $sqlCN = "SELECT county,sub_county,facility FROM facility_map WHERE `mfl`='$hub'";
    $qCN = mysqli_query($dbConn, $sqlCN) or die(mysqli_error($dbConn));
    $rwCN = mysqli_fetch_assoc($qCN);
    $cname = mysqli_real_escape_string($dbConn, $rwCN['county']); //name of county
    $scname = mysqli_real_escape_string($dbConn, $rwCN['sub_county']); //name of county
    $fcname = mysqli_real_escape_string($dbConn, $rwCN['facility']); //name of county

    $sqlCN = "SELECT county,sub_county,facility FROM facility_map WHERE `mfl`='$facilitycode'";
    $qCN = mysqli_query($dbConn, $sqlCN) or die(mysqli_error($dbConn));
    $rwCN = mysqli_fetch_assoc($qCN);
    $ref_fac = mysqli_real_escape_string($dbConn, $rwCN['facility']); //name of county
    $ref_county = mysqli_real_escape_string($dbConn, $rwCN['county']); //name of county
    $ref_sc = mysqli_real_escape_string($dbConn, $rwCN['sub_county']); //name of county
    $fname = mysqli_real_escape_string($dbConn, $_POST['fnname']);
    $mname = mysqli_real_escape_string($dbConn, $_POST['mname']);
    $lname = mysqli_real_escape_string($dbConn, $_POST['lname']);
    $fullname = $fname . ' ' . $mname . ' ' . $lname;
    $address = mysqli_real_escape_string($dbConn, $_POST['address']);
    $fcname = mysqli_real_escape_string($dbConn, $_SESSION['facility']);
    //exit;
    $sql = "INSERT INTO sample1 (`lab_no`,`op_no`,`id_no`,`dept`,`regno`, `fullname`, `fnname`,`mname`,`lname`, `gender`, `age`,`ageb`, `mobile`,`address`,`pat_type`,`facility`,`Refacility`,`coldate`,`h_status`,`exam_req`,`specimen_type`,`d_email`,`c_no`,`c_name`,`c_email`,`s_email`,`s_no`,`on_off`,`county`,`sub_county`,`fname`,`ref_county`,`ref_sc`,`ref_fname`,cond,`dispatched`) VALUES (
        '$lab_no',
        '$_POST[opno]',
        '$id_no',
        '$_POST[dept]',
        '$_POST[regno]',
        '$fullname',
        '$fname',
        '$mname',
        '$lname',
        '$_POST[gender]',
        '$p_age',
        '$_POST[ageb]',
        '$_POST[p_no]',
        '$address',
        '$_POST[ptype]',
        '$hub',
        '$facilitycode',
        '$_POST[date]',
        '$_POST[hstatus]',
        '$_POST[exam]',
        '$_POST[specimen_type]',
        '$_POST[d_email]',
        '$_POST[c_no]',
        '$_POST[c_name]',
        '$_POST[c_email]',
        '$_POST[s_email]',
        '$_POST[s_no]','1','$cname','$scname','$fcname','$ref_county','$ref_sc','$ref_fac', '2',0)";
    // exit;

    $retval = mysqli_query($dbConn, $sql);
    if (!$retval) {
        $msg = 0;
    } else {
        $msg = 1;
    }

    echo "<script>";
    echo "window.location.href='presumptive.php?msg=$msg'";
    echo "</script>";
}

?>

<div class="main-content" style="margin-top: -1%">
    <?php include("Aheader.php");     ?>
    <hr />

    <div class="row">
        <div class="col-md-12">


            <div class="panel minimal minimal-gray">

                <div class="panel-heading">
                    <!--<div class="panel-title"><h4>Presumptive Register </h4></div>

<div class="col-sm-5" style="float: right">
    
    <div class="input-group">
    <label><strong><font color="red"></font>Search By Ip/Op No or TB Reg No: </strong></label>
    <input class="form-control" type="text" name="search" id="search" autocomplete="off"><label  for="field-1">  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </label>
    <span class="input-group-btn" style="vertical-align: bottom;"><input class="btn btn-primary" type="submit" id="btnsearch" name="btnsearch" value="Search" />
    </span>
    </div>

</div> -->

                </div>

                <div class="panel-body" id="my-div me_1">

                    <div class="panel panel-gradient" data-collapsed="0">

                        <!-- panel head -->
                        <div class="panel-heading">
                            <div class="panel-title">Presumptive Register </div>
                        </div>

                        <!-- panel body -->
                        <div class="panel-body">
                            <?php
                            if (isset($_GET['msg'])) {
                                $msg = $_GET['msg'];

                                if ($msg == 1) {

                                    echo '<div style="text-align: center;width: 250px;" class="alert alert-success">Patient details successfully saved <a href="presumptive.php" data-rel="close" style="float: right;"><i class="entypo-cancel"></i></a></div>';
                                } else {

                                    echo '<div style="text-align: center;width: 250px;" class="alert alert-warning">Could not enter data.Try Again<a href="presumptive.php" data-rel="close" style="float: right;"><i class="entypo-cancel"></i></a></div>';
                                }
                            }
                            ?>
                            <form name="save" id="save" class="validate" method="post" role="form">


                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="field-1"><strong>
                                                <font color="red"></font>Op/IP No
                                            </strong></label>
                                        <input type="text" class="form-control" id="opno" name="opno" placeholder="Op/IP No" />
                                    </div>
                                </div>


                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="field-1"><strong>
                                                <font color="red"></font>TB Reg No
                                            </strong></label>
                                        <input type="text" class="form-control" id="regno" name="regno" placeholder="TB Reg No" />
                                    </div>
                                </div>
                                <div class="col-md-2">
									<div class="form-group">
										<label for="field-1"><strong>
												<font color="red"></font>ID No
											</strong></label>
										<input type="text" class="form-control" id="id_no" name="id_no" placeholder="ID NO" />
									</div>
								</div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="field-1">
                                            <strong>
                                                <font color="red">*</font>Department
                                            </strong>
                                        </label>
                                        <select name="dept" id="dept" class="form-control" required>
                                            <option value="">Select Dept</option>
                                            <?php
                                            do {
                                            ?>
                                                <option value="<?php echo $row_dept['name'] ?>"><?php echo $row_dept['name']; ?></option>
                                            <?php
                                            } while ($row_dept = mysqli_fetch_assoc($dept));
                                            $rows = mysqli_num_rows($dept);
                                            if ($rows > 0) {
                                                mysqli_data_seek($dept, 0);
                                                $row_dept = mysqli_fetch_assoc($dept);
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="clear"></div>
                                <br />
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="field-1"><strong>
                                                <font color="red">*</font>First Name
                                            </strong></label>
                                        <input type="text" name="fnname" id="fnname" data-validate="required,name" class="form-control" placeholder="First Name">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="field-1"><strong>
                                                <font color="red">*</font>Middle Name
                                            </strong></label>
                                        <input type="text" name="mname" id="mname" data-validate="required,name" class="form-control" placeholder="Middle Name">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="field-1"><strong>
                                                <font color="red">*</font>Last Name
                                            </strong></label>
                                        <input type="text" name="lname" id="lname" data-validate="required,name" class="form-control" placeholder="Last Name">
                                    </div>
                                </div>
                                <div class="col-md-1">
                                    <div class="form-group">
                                        <label for="field-1"><strong>
                                                <font color="red">*</font>Age
                                            </strong></label>
                                        <!-- <input type="text" data-validate="required,number" name="age" id="age" class="form-control" placeholder="Age" />-->
                                        <input type="text" data-validate="required,number" maxlength="3" name="p_age" id="p_age" class="form-control" placeholder="Age" />
                                    </div>
                                </div>

                                <div class="col-md-1">
                                    <label for="field-1"><strong> &nbsp;&nbsp; </strong></label>
                                    <select name="ageb" id="ageb" class="form-control">
                                        <option value="1">Year(s)</option>
                                        <option value="0">Month(s)</option>
                                    </select>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="field-1"><strong>
                                                <font color="red">*</font>Sex
                                            </strong></label>
                                        <select name="gender" id="gender" class="form-control" required>
                                            <option value="">Select Gender</option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="field-1"><strong>
                                                <font color="red"></font>Patient Mobile No
                                            </strong></label>
                                        <!-- <input type="text" name="p_no" id="p_no" class="form-control" data-validate="number" maxlength="12" data-mask="999999999999" value="2547" placeholder="Patient Mobile No" data-original-title="Patient Mobile No" data-content="The number should start with the 2547 Format." data-placement="right" data-trigger="hover" data-toggle="popover" /> -->
                                        <input type="text" name="p_no" id="p_no" class="form-control" data-mask="999999999999" value="2547" placeholder="Patient Mobile No" data-original-title="Patient Mobile No" data-content="The number should start with the 2547 Format." data-placement="right" data-trigger="hover" data-toggle="popover" />
                                    </div>
                                </div>

                                <div class="clear"></div>
                                <br />

                                <div class="col-md-2">
                                    <label for="field-1"><strong>Residence</strong></label>
                                    <input type="text" name="address" id="address" class="form-control" placeholder="Physical Address">
                                </div>


                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="field-1"><strong>
                                                <font color="red">*</font>Type of Patient
                                            </strong></label>
                                        <select name="ptype" id="ptype" class="form-control" required>
                                            <option value="">Type of Patient</option>
                                            <?php
                                            do {
                                            ?>
                                                <option value="<?php echo $row_rstype_of_patient['type'] ?>"><?php echo $row_rstype_of_patient['type']; ?></option>
                                            <?php
                                            } while ($row_rstype_of_patient = mysqli_fetch_assoc($rstype_of_patient));
                                            $rows = mysqli_num_rows($rstype_of_patient);
                                            if ($rows > 0) {
                                                mysqli_data_seek($rstype_of_patient, 0);
                                                $row_rstype_of_patient = mysqli_fetch_assoc($rstype_of_patient);
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="field-1"><strong>
                                                <font color="red">*</font>Hiv Status
                                            </strong></label>
                                        <select name="hstatus" id="hstatus" class="form-control" required>
                                            <option value="">Select Status</option>
                                            <?php
                                            do {
                                            ?>
                                                <option value="<?php echo $row_rshiv_status['status'] ?>"><?php echo $row_rshiv_status['status']; ?></option>
                                            <?php
                                            } while ($row_rshiv_status = mysqli_fetch_assoc($rshiv_status));
                                            $rows = mysqli_num_rows($rshiv_status);
                                            if ($rows > 0) {
                                                mysqli_data_seek($rshiv_status, 0);
                                                $row_rshiv_status = mysqli_fetch_assoc($rshiv_status);
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="field-1"><strong>
                                                <font color="red">*</font>Specimen Type
                                            </strong></label>
                                        <select name="specimen_type" id="specimen_type" class="form-control" required>
                                            <option value="">Select specimen</option>
                                            <?php
                                            do {
                                            ?>
                                                <option value="<?php echo $row_rsST['type'] ?>"><?php echo $row_rsST['type']; ?></option>
                                            <?php
                                            } while ($row_rsST = mysqli_fetch_assoc($rsST));
                                            $rows = mysqli_num_rows($rsST);
                                            if ($rows > 0) {
                                                mysqli_data_seek($rsST, 0);
                                                $row_rsST = mysqli_fetch_assoc($rsST);
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="field-1"><strong>
                                                <font color="red">*</font>Date of Sample Collection
                                            </strong></label>
                                        <div class="input-group">
                                            <input type="text" id="date" name="date" data-validate="required" class="form-control datepicker" data-format="dd-M-yyyy" data-end-date="d" placeholder="Select Date">
                                            <div class="input-group-addon">
                                                <a href="#">
                                                    <i class="entypo-calendar"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clear"></div>
                                <br />
                               

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="field-1"><strong>
                                                <font color="red">*</font>Examination Required
                                            </strong></label>
                                        <select name="exam" id="exam" class="form-control" required>
                                            <option value="">Select Examination</option>
                                            <?php
                                            do {
                                            ?>
                                                <option value="<?php echo $row_rsexamination_required['type'] ?>"><?php echo $row_rsexamination_required['type']; ?></option>
                                            <?php
                                            } while ($row_rsexamination_required = mysqli_fetch_assoc($rsexamination_required));
                                            $rows = mysqli_num_rows($rsexamination_required);
                                            if ($rows > 0) {
                                                mysqli_data_seek($rsexamination_required, 0);
                                                $row_rsexamination_required = mysqli_fetch_assoc($rsexamination_required);
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                               
                                <div class="clear"></div>
                                <br />


                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="field-1"><strong>Clinician Name</strong></label>
                                        <input type="text" name="c_name" id="c_name" value="<?php echo $user; ?>" class="form-control" placeholder="Clinician Name">
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="field-1"><strong>Clinician Email</strong></label>
                                        <input type="text" class="form-control" id="c_email" name="c_email" value="<?php echo $email; ?>" data-validate="email" placeholder="Clinician Email" list="clemail_list" />
                                        <div id="res_clmail"></div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="field-1"><strong>Clinician Mobile No</strong></label>
                                        <input type="text" name="c_no" id="c_no" data-validate="required,number" maxlength="12" list="clno_list" value="<?php echo $phone; ?>" class="form-control" placeholder="Clinician Mobile No" data-original-title="Clinician Mobile No" data-content="The number should start with the 2547 Format." data-placement="right" data-trigger="hover" data-toggle="popover" />
                                        <div id="res_cno"></div>
                                    </div>
                                </div>

                                <div class="clear"></div>
                                <br />
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="field-1"><strong>CTLC Email </strong></label>
                                        <input type="text" class="form-control" name="d_email" id="d_email" data-validate="email" placeholder="CTLC Email" list="ctemail_list" />
                                        <div id="res_ctmail"></div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="field-1"><strong>SCTLC Email </strong></label>
                                        <input type="text" class="form-control" name="s_email" id="s_email" data-validate="email" placeholder="SCTLC Email" list="semail_list" />
                                        <div id="res_semail"></div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="field-1"><strong>SCTLC Mobile No</strong></label>
                                        <input type="text" name="s_no" id="s_no" data-validate="required,number" maxlength="12" list="sno_list" value="2547" class="form-control" placeholder="SCTLC Mobile No" data-original-title="SCTLC Mobile No" data-content="The number should start with the 2547 Format." data-placement="right" data-trigger="hover" data-toggle="popover" />
                                        <div id="res_sno"></div>
                                    </div>
                                </div>

                                <div class="clear"></div>
                                <br />
                                <div class="col-md-12" align="center">
                                    <button class="btn btn-success" type="submit" name="btnUpload" id="btnUpload">Save Details</button>
                                    <button class="btn" type="reset">Reset</button>
                                </div>

                            </form>

                        </div>

                    </div>


                </div>

            </div>

        </div>
    </div>

    <!-- Footer -->
    <footer class="main">

        <div class="pull-right">
            <?php
            include '../includes/footer.php';
            ?>
        </div>

    </footer>
</div>
<link rel="stylesheet" href="../assets/neon/neon-x/assets/js/select2/select2-bootstrap.css" id="style-resource-1">
<link rel="stylesheet" href="../assets/neon/neon-x/assets/js/select2/select2.css" id="style-resource-2">



<script src="../assets/neon/neon-x/assets/js/gsap/main-gsap.js" id="script-resource-1"></script>
<script src="../assets/neon/neon-x/assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js" id="script-resource-2"></script>
<script src="../assets/neon/neon-x/assets/js/bootstrap.min.js" id="script-resource-3"></script>
<script src="../assets/neon/neon-x/assets/js/joinable.js" id="script-resource-4"></script>
<script src="../assets/neon/neon-x/assets/js/resizeable.js" id="script-resource-5"></script>
<script src="../assets/neon/neon-x/assets/js/neon-api.js" id="script-resource-6"></script>
<script src="../assets/neon/neon-x/assets/js/bootstrap-datepicker.js" id="script-resource-11"></script>
<script src="../assets/neon/neon-x/assets/js/jquery.validate.min.js" id="script-resource-7"></script>
<script src="../assets/neon/neon-x/assets/js/jquery.inputmask.bundle.min.js" id="script-resource-7"></script>
<script src="../assets/neon/neon-x/assets/js/select2/select2.min.js" id="script-resource-7"></script>
<script src="../assets/neon/neon-x/assets/js/neon-chat.js" id="script-resource-8"></script>
<script src="../assets/neon/neon-x/assets/js/bootstrap-tagsinput.min.js" id="script-resource-8"></script>


<link rel="stylesheet" href="../assets/neon/neon-x/assets/js/select2/select2-bootstrap.css" id="style-resource-1">
<link rel="stylesheet" href="../assets/neon/neon-x/assets/js/select2/select2.css" id="style-resource-2">
<script src="../assets/neon/neon-x/assets/js/bootstrap-tagsinput.min.js" id="script-resource-8"></script>
<script src="../assets/neon/neon-x/assets/js/jquery.inputmask.bundle.min.js" id="script-resource-7"></script>
<script src="../assets/neon/neon-x/assets/js/gsap/main-gsap.js" id="script-resource-1"></script>
<script src="../assets/neon/neon-x/assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js" id="script-resource-2"></script>
<script src="../assets/neon/neon-x/assets/js/bootstrap.min.js" id="script-resource-3"></script>
<script src="../assets/neon/neon-x/assets/js/joinable.js" id="script-resource-4"></script>
<script src="../assets/neon/neon-x/assets/js/resizeable.js" id="script-resource-5"></script>
<script src="../assets/neon/neon-x/assets/js/neon-api.js" id="script-resource-6"></script>
<script src="../assets/neon/neon-x/assets/js/jquery.dataTables.min.js" id="script-resource-7"></script>
<script src="../assets/neon/neon-x/assets/js/dataTables.bootstrap.js" id="script-resource-8"></script>
<script src="../assets/neon/neon-x/assets/js/select2/select2.min.js" id="script-resource-9"></script>
<script src="../assets/neon/neon-x/assets/js/neon-chat.js" id="script-resource-10"></script>
<script src="../assets/neon/neon-x/assets/js/neon-custom.js" id="script-resource-11"></script>
<script src="../assets/neon/neon-x/assets/js/neon-demo.js" id="script-resource-12"></script>
<script src="../assets/neon/neon-x/assets/js/toastr.js" id="script-resource-7"></script>
<script src="../assets/neon/neon-x/assets/js/bootstrap-datepicker.js" id="script-resource-11"></script>
<script type="text/javascript" src="../assets/js/jquery-multi-select/js/jquery.multi-select.js"></script>
<script src="../assets/js/select2/select2.js"></script>
<script src="../assets/js/select-init.js"></script>

<script type="text/javascript">
    $(document).ready(function() {


        $('#s_col').change(function() {
            var br = $("#s_col").val();
            //alert(br);

            if (br == 'C') {
                $("#sample_col").show();
            } else {
                $("#sample_col").hide();
            };


        }); // End of  keyup function

    }); // End of document.ready
</script>

</body>

</html>