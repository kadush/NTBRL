
<?php
session_start();
error_reporting(0);
// echo 'id='.session_id(). ' other = '.var_dump($_SESSION);
// echo $username = $_SESSION['nm'];
require_once('../connection/db.php'); //connection file
/* check level of user(to avoid url injection))*/
// if ($_SESSION['nm'] == "" or $_SESSION['cat'] != 3) {
// 	//redirect to login page
// 	header("location:../includes/logout.php");
// 	exit;
// }

//var_dump($_SESSION);

if (isset($_SESSION['nm'])) {
	// logged in !
	$username = $_SESSION['nm'];
}
if (isset($_SESSION['facility'])) {
	$facilityname = $_SESSION['facility']; //set facility mflcode from session upon login
}

if (isset($_SESSION['mfl'])) {
	$facilitycode = $_SESSION['mfl']; //set facility mflcode from session upon login
	$table = $_SESSION['table'];
}



$sql1 = "SET sql_mode=(SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''));";
$result = mysqli_query($dbConn, $sql1) or die(mysqli_error($dbConn));

$maximumyear = date('Y');
$minyear  = 2011;
?>
<link rel="stylesheet" href="../assets/neon/neon-x/assets/frontend/css/bootstrap-min.css" id="style-resource-1">
<link rel="stylesheet" href="../assets/neon/neon-x/assets/frontend/css/font-icons/entypo/css/entypo.css" id="style-resource-2">
<link rel="stylesheet" href="../assets/neon/neon-x/assets/frontend/css/neon.css" id="style-resource-3">
<link rel="stylesheet" href="../assets/neon/neon-x/assets/css/neon.css" id="style-resource-5">


<header class="site-header">
	<!-- Profile Info and Notifications -->
	<div class="col-md-6 col-sm-8 clearfix">

		<ul class="user-info pull-left pull-none-xsm">

			<!-- Profile Info -->
			<li class="profile-info dropdown">
				<!-- add class "pull-right" if you want to place this from right 
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
					<img src="../assets/img/tibuLims.jpg" class="img-responsive" />
				</a> -->
			</li>

		</ul>
	</div>


	<!-- Raw Links -->
	<div class="col-md-6 col-sm-8 clearfix">

		<ul class="user-info pull-right pull-none-xsm">
			<li>
				<?php
				date_default_timezone_set('Europe/Moscow');

				$script_tz = date_default_timezone_get();
				?>
				<?php echo "<b>" . @date("l, d F Y"); ?>
			<li class="sep"></li> <br>Welcome <img src="../assets/img/icons/users.png" height="15" /><?php echo  $_SESSION['nm'] . " [ " . $_SESSION['facility'] . " ]";; ?>

			</li>

		</ul>

	</div>
	<nav class="site-nav">

		<ul class="main-menu hidden-xs" id="main-menu">
			<?php if ($reportedpreviousmonth > 0) { ?>
				<li>
					<a href="index.php"><i class="entypo-home"></i><span>Home</span></a>
				</li>
				<li>
					<a>
						<i class="entypo-bag"></i><span>Samples</span>
					</a>

					<ul style="width: 100%">
						<li>
							<a href="sampleview.php"><span><i class="entypo-suitcase"></i></span><span>Sample List</span>
								<div id='worksheet1' style="margin-bottom: 20px;max-width: 20px; float: right"></div>
							</a>
						</li>
						<li>
							<a href="inc.php"><span><i class="entypo-suitcase"></i></span><span>Done Offline</span>
								<div id='response1' style="margin-bottom: 20px;max-width: 20px; float: right"></div>
							</a>
						</li>
						<li>
							<a href="allsampleview.php"><span><i class="entypo-suitcase"></i></span><span>Complete Records</span><span class="badge badge-success" style="float: right;"><?php echo $complete; ?></span></a>
						</li>
						<li>
							<a href="sampleErr.php"><span><i class="entypo-suitcase"></i></span><span>Error Records</span><span class="badge badge-danger" style="float: right;"><?php echo $errors; ?></span></a>
						</li>

					</ul>
				</li>
				<li>
					<a href="dashboard.php"><i class="entypo-gauge"></i><span>Dashboard</span></a>
				</li>

				<li>
					<a href="facility.php"><i class="entypo-vcard"></i><span>Referral Facilities</span></a>
				</li>

				<li>
					<a href="#"><i class="entypo-list-add"></i><span>Consumption Report</span></a>

					<ul>
						<li>
							<a href="viewconsumption.php"><i class="entypo-list-add"></i><span>View Consumption</span></a>
						</li>

						<li><a href="updateinv.php"><i class="entypo-list-add"></i><span>Update Inventory</span></a></li>

					</ul>
				</li>
				<li>
					<a href="issue.php"><i class="entypo-cog"></i><span>SLA</span></a>
				</li>
				<li>
					<a href="summ.php"><i class="entypo-archive"></i><span>Reports</span></a>
				</li>

			<?php } else { ?>
				<li>
					<a href="pendings.php"><i class="entypo-home"></i><span>Home</span></a>
				</li>
			<?php } ?>
			<li style="float: right">
				<a href="../includes/logout.php">
					Log Out <i class="entypo-logout right"></i>
				</a>
			</li>
		</ul>


		<div class="visible-xs">

			<a href="#" class="menu-trigger">
				<i class="entypo-menu"></i>
			</a>

		</div>
	</nav>
</header>

<script src="../assets/neon/neon-x/assets/frontend/js/gsap/main-gsap.js" id="script-resource-1"></script>
<script src="../assets/neon/neon-x/assets/frontend/js/bootstrap.js" id="script-resource-2"></script>
<script src="../assets/neon/neon-x/assets/frontend/js/joinable.js" id="script-resource-3"></script>
<script src="../assets/neon/neon-x/assets/frontend/js/resizeable.js" id="script-resource-4"></script>
<script src="../assets/neon/neon-x/assets/frontend/js/neon-slider.js" id="script-resource-5"></script>
<script src="../assets/neon/neon-x/assets/frontend/js/neon-custom.js" id="script-resource-6"></script>