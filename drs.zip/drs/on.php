<?php
session_start();
require_once('../connection/db.php');
$query_rssample = "SELECT * FROM tr_sample1_view WHERE received='0' and dispatched='0' and Refacility='$facilitycode'";
$rssample = mysqli_query($dbConn, $query_rssample) or die(mysqli_error($dbConn));
$row_rssample = mysqli_fetch_assoc($rssample);
$total = mysqli_num_rows($rssample);
require_once('../connection/db.php'); //connection file
//include('includes/functions.php');
$facilitycode = $_SESSION['mfl']; //set facility mflcode from session upon login

//echo $_SESSION['cat'];
if ($facilitycode == '') {
    header("location:../index.php");
} else {

    /* check level of user(to avoid url injection)) or $_SESSION['cat'] != 2  or $_SESSION['cat'] != 3 */
    if ($_SESSION['nm'] == "") {
        //redirect to login page
        //echo 'wrong';
        header("location:../index.php");
    }

    if (isset($_SESSION['mfl'])) {
        $FacID = $_SESSION['mfl']; //set facility mflcode from session upon login

        $q = "SELECT mfl FROM tr_hubs WHERE id in (select hub from tr_spokes where mfl='$FacID')";
        $r = mysqli_query($dbConn, $q) or die(mysqli_error($dbConn));
        $row = mysqli_fetch_assoc($r);
        $hub = $row['mfl'];


        $q = "SELECT 
		(
		SELECT count(ID) FROM tr_sample1_view WHERE cond=1 and Refacility='$FacID'
		)AS complete, 
		(
		SELECT count(ID) FROM tr_sample1_view WHERE MONTH(End_Time)=MONTH(CURRENT_TIMESTAMP) and  YEAR(End_Time)=YEAR(CURRENT_TIMESTAMP) and Test_Result='Positive' and cond=1 and Refacility='$FacID'
		)AS mtb, 
		(
		SELECT count(ID) FROM tr_sample1_view WHERE MONTH(End_Time)=MONTH(CURRENT_TIMESTAMP) and  YEAR(End_Time)=YEAR(CURRENT_TIMESTAMP) and mtbRif='Positive' and cond=1 and Refacility ='$FacID'
		)AS rif, 
		(
		  SELECT count(ID) FROM tr_sample1_view WHERE MONTH(tym)=MONTH(CURRENT_TIMESTAMP) and  YEAR(tym)=YEAR(CURRENT_TIMESTAMP) and dispatched=1 and Refacility='$FacID'
		)AS dispatched,
		(
		  SELECT count(ID) FROM tr_sample1_view WHERE MONTH(tym)=MONTH(CURRENT_TIMESTAMP) and  YEAR(tym)=YEAR(CURRENT_TIMESTAMP) and cond=2 and Refacility='$FacID'
		)AS notdispatched,
		(
		 SELECT count(ID) FROM tr_sample1_view WHERE MONTH(tym)=MONTH(CURRENT_TIMESTAMP) and  YEAR(tym)=YEAR(CURRENT_TIMESTAMP) and Refacility='$FacID'
		)AS totalcol";
        $r = mysqli_query($dbConn, $q) or die(mysqli_error($dbConn));
        $row = mysqli_fetch_assoc($r);
        $complete = $row['complete'];
        $totalcol = $row['totalcol'];
        $dispatched = $row['dispatched'];
        $notdispatched = $row['notdispatched'];
        $mtb = $row['mtb'];
        $rif = $row['rif'];

        $query_rsCXR = "SELECT outcome FROM tr_cxr ORDER BY id";
        $rsCXR = mysqli_query($dbConn, $query_rsCXR) or die(mysqli_error($dbConn));
        $row_rsCXR = mysqli_fetch_assoc($rsCXR);
        $totalRows_rsCXR = mysqli_num_rows($rsCXR);
    }

    function GetMaxYear()
    {

        $showyear = date('Y');

        return $showyear;
    }
    /* to be used in reporting(summ.php)*/

    /* function for earliest year of testing/reporting*/
    function GetMinYear()
    {


        $showyear = 2019;


        return $showyear;
    }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><![endif]-->

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Neon Admin Panel" />
    <meta name="author" content="Laborator.co" />

    <title>NTLD-P | Spoke</title>
    <link rel="icon" href="../img/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="../assets/neon/neon-x/assets/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css" id="style-resource-1">
    <link rel="stylesheet" href="../assets/neon/neon-x/assets/css/font-icons/entypo/css/entypo.css" id="style-resource-2">
    <link rel="stylesheet" href="../assets/neon/neon-x/assets/css/font-icons/entypo/css/animation.css" id="style-resource-3">
    <link rel="stylesheet" href="../assets/neon/neon-x/assets/css/neon.css" id="style-resource-5">
    <link rel="stylesheet" href="../assets/neon/neon-x/assets/css/custom.css" id="style-resource-6">

    <script src="../assets/neon/neon-x/assets/js/jquery-1.10.2.min.js"></script>
    <!-- <link rel="stylesheet" href="../FusionCharts/Contents/Style.css" type="text/css" />
    <script language="JavaScript" src="../FusionMaps/JSClass/FusionMaps.js"></script>
    <script language="JavaScript" src="../FusionCharts/FusionCharts.js"></script> -->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	  <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
	<![endif]-->

    <!-- TS1387506872: Neon - Responsive Admin Template created by Laborator -->
</head>

<body class="page-body loaded">

    <div class="page-container">

        <div class="sidebar-menu">

            <header class="logo-env">

                <!-- logo -->
                <!-- <div class="logo">
			<a href="index.php">
				<img src="../img/gx.jpg" class="img-responsive" alt="Responsive image" style="width: 170px" />
			</a>
		</div> -->

                <!-- logo collapse icon -->
                <div class="sidebar-collapse">
                    <a href="#" class="sidebar-collapse-icon with-animation">
                        <!-- add class "with-animation" if you want sidebar to have animation during expanding/collapsing transition -->
                        <i class="entypo-menu"></i>
                    </a>
                </div>


                <!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
                <div class="sidebar-mobile-menu visible-xs">
                    <a href="#" class="with-animation">
                        <!-- add class "with-animation" to support animation -->
                        <i class="entypo-menu"></i>
                    </a>
                </div>

            </header>

            <ul id="main-menu" class="">

                <li>
                    <a href="index.php"><i class="entypo-gauge"></i><span>Dashboard</span></a>

                </li>

                <li>
                    <a href="presumptive.php"><i class="entypo-user-add"></i><span>Add Presumptive Case</span></a>
                </li>

                <li>
                    <a href="p_view.php"><i class="entypo-docs"></i><span>View Presumptive Cases</span>
                        <div id='' style="margin-bottom: 20px;max-width: 20px; float: right"><span class="badge badge-warning" style="float: right;"><?php echo $notdispatched ?></span></div>
                    </a>
                </li>
                <li>
                    <a href="dispatched.php"><i class="entypo-upload"></i><span>Dispatched Samples</span>
                        <div id='' style="margin-bottom: 20px;max-width: 20px; float: right"><span class="badge badge-success" style="float: right;"><?php echo $dispatched ?></span></div>
                    </a>
                </li>
                <li>
                    <a href="adduser.php"><i class="entypo-user-add"></i><span>Add User</span></a>
                </li>
                <li>
                    <a href="changePass.php"><i class="entypo-user"></i><span>Change Password</span></a>
                </li>
            </ul>


        </div>
        <div class="main-content" style="margin-top: -1%">
        <div class="row">
	
	<!-- Profile Info and Notifications -->
	<div class="col-md-6 col-sm-8 clearfix">
		
		<ul class="user-info pull-left pull-none-xsm">
		
			<!-- Profile Info -->
			<li class="profile-info dropdown"><!-- add class "pull-right" if you want to place this from right -->
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
					<img src="../assets/img/ntlp.jpg" class="img-responsive" />
				</a>
		    </li>
		
		</ul>
	</div>
	
	
	<!-- Raw Links -->
	<div class="col-md-6 col-sm-8 clearfix">
		
		<ul class="user-info pull-right pull-none-xsm">
			<li>
				<?php
					date_default_timezone_set('Europe/Moscow');
					
					$script_tz = date_default_timezone_get();
					?>
					<?php echo "<b>". @date("l, d F Y");?> <li class="sep"></li> <br>Welcome <img src="../assets/img/icons/users.png" height="15" /><?php echo  $_SESSION['nm']." [ " . $_SESSION['facility'] . " ]"; ;?> 
		
			</li>
					
			<br>
			<br>
			<span >
				<li style="float: right"><a href="../includes/logout.php">Log Out <i class="entypo-logout right"></i></a></li>
			</span>
			
		</ul>
		
	</div>
	
</div>


            <hr />

            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-gradient" data-collapsed="0">

                        <div class="panel-heading">
                            <div class="panel-title">
                                All Presumptive Cases - Awaiting Dispatch
                            </div>

                            <div class="panel-options">
                                <span class="tools pull-right" style="vertical-align: top">
                                    <button name="verivyBTN" id="verivyBTN" class="btn btn-success" type="button" onclick="updateItem()">
                                        <font color="ffff"><i class="fa fa-check"></i> Dispatch to Hub</font>
                                    </button>
                                </span>
                            </div>
                        </div>

                        <div class="panel-body">

                            <table class="table table-bordered datatable" id="table-1">
                                <thead>
                                    <tr>
                                        <th>##</th>
                                        <th>Patient Name</th>
                                        <th>ID No</th>
                                        <th>Age</th>
                                        <th>Phone No</th>
                                        <th>Physical Address</th>
                                        <th>Sample Status</th>
                                        <th>Sample collection</th>
                                        <th>Actions</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php

                                    if ($total == 0) {
                                        # code...
                                    } else {

                                        do {

                                            if ($row_rssample['s_col'] == 'C') {

                                                $row_rssample['s_col'] = 'Sample Produced';
                                            } else {

                                                $row_rssample['s_col'] = 'Patient referred';
                                            }


                                            if ($row_rssample['dispatched'] == '1') {
                                                $row_rssample['dispatched'] = 'Transported to hub';
                                                $link = '';
                                            } else {
                                                $row_rssample['dispatched'] = 'Awaiting rider collection';
                                                $link = '<a href="editTR.php?id=' . $row_rssample['ID'] . '"><img src="../assets/img/icons/edit.png" height="20" alt="Edit" title="Edit Patient Details "/>Edit</a> 
                    ';
                                            }

                                            ?>
                                            <tr class="odd gradeX">
                                                <td>
                                                    <div class="checkbox">
                                                        <label>
                                                            <input type="checkbox" name="verify[]" id="<?php echo $row_rssample['ID']; ?>" />
                                                        </label>
                                                    </div>
                                                </td>
                                                <td> <?php echo $row_rssample['fullname']; ?></td>
                                                <td> <?php echo $row_rssample['id_no']; ?></td>
                                                <td> <?php echo $row_rssample['age']; ?></td>
                                                <td> <?php echo $row_rssample['mobile']; ?></td>
                                                <td> <?php echo $row_rssample['address']; ?></td>
                                                <td> <?php echo $row_rssample['s_col']; ?></td>
                                                <td> <?php echo $row_rssample['dispatched']; ?></td>

                                                <td>
                                                    <a title="View Full Profile" class="btn btn-info btn-sm btn-icon icon-left" data-toggle="modal" data-target="#<?php echo $row_rssample['ID']; ?>">
                                                        <i class="entypo-info"></i>
                                                        &nbsp;
                                                    </a>
                                                    <?php echo $link; ?>
                                                </td>
                                            </tr>

                        </div>
                        <!-- Modal -->
                        <div class="modal fade" id="<?php echo $row_rssample['ID']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title" id="myModalLabel">Patient Information</h4>
                                    </div>
                                    <div class="modal-body">
                                        <div class="col-md-4">
                                            <label for="field1">Lab No: </label> <?php echo $row_rssample['ln']; ?>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="field1">Full Name: </label>
                                            <?php echo $row_rssample['fullname']; ?>
                                        </div>
                                        <div class="col-md-4">
                                            <label>Age: </label><?php echo $row_rssample['age']; ?>
                                        </div>
                                        <div class="col-md-4">
                                            <label>Gender: </label><?php echo $row_rssample['gender']; ?>
                                        </div>
                                        <div class="col-md-4">
                                            <label>Mobile No: </label><?php echo $row_rssample['mobile']; ?>
                                        </div>
                                        <div class="col-md-4"><label for="field3">Physical address: </label>
                                            <?php echo $row_rssample['address']; ?>
                                        </div>

                                        <div class="col-md-4"><label for="field3">Clinician Name: </label>
                                            <?php echo $row_rssample['c_name']; ?>
                                        </div>

                                        <div class="col-md-4"><label for="field3">Date of collection: </label>
                                            <?php echo $row_rssample['coldate']; ?>
                                        </div>
                                    </div>

                                </div>


                            </div>
                        </div>
                <?php } while ($row_rssample = mysqli_fetch_assoc($rssample));
                } ?>

                </tbody>
                </table>
                <!-- Modal 3 (Custom Width)-->
    <div class="modal fade custom-width" id="modal-77">
        <div class="modal-dialog" style="width: 96%">
            <div class="modal-content">
                <div class="modal-header"> <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">Full width</h4>
                </div>
                <div class="modal-body">
                <form name="save_rider" id="save_rider" class="validate" method="post" role="form">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Date of sample collection:</label>
                                            <div class="input-group">
                                                <input type="text" id="datecol" name="datecol" data-validate="required" class="form-control datepicker" data-format="yyyy-mm-dd" data-end-date="d" placeholder="Select Date">
                                                <div class="input-group-addon">
                                                    <a href="#">
                                                        <i class="entypo-calendar"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" id="samp" name="samp">

                                    <div class="clear"></div>
                                    <br>

                                </form>
                </div>
                <div class="modal-footer"> <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> <button type="button" class="btn btn-info">Save changes</button> </div>
            </div>
        </div>
    </div>
                <!-- Modal 1 (Basic)-->
                <div class="modal fade" id="modal-7" style="display:
					none;">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header"> <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                <h4 class="modal-title">Basic Modal</h4>
                            </div>
                            <div class="modal-body">
                                Hello I am a Modal!
                            </div>
                            <div class="modal-footer"> <button type="button" class="btn
									btn-default" data-dismiss="modal">Close</button> <button type="button" class="btn btn-info">Save changes</button> </div>
                        </div>
                    </div>
                </div>
                <!-- Modal 7 (Ajax Modal)-->
                <!-- Modal 7 (Ajax Modal)-->
                <div class="modal fade" id="modal-1">
                    <div class="modal-dialog">
                        <div float="right" class="modal-content" style="max-width: 500px;">

                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title">Update Rider for samples : <label id="samples"></label>
                                </h4>
                            </div>

                            <div class="modal-body">

                                <form name="save_rider" id="save_rider" class="validate" method="post" role="form">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Date of sample collection:</label>
                                            <div class="input-group">
                                                <input type="text" id="datecol" name="datecol" data-validate="required" class="form-control datepicker" data-format="yyyy-mm-dd" data-end-date="d" placeholder="Select Date">
                                                <div class="input-group-addon">
                                                    <a href="#">
                                                        <i class="entypo-calendar"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" id="samp" name="samp">

                                    <div class="clear"></div>
                                    <br>

                                </form>

                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                <button class="btn btn-info" name="btnUpload" id="btnUpload" type="button" onClick="update()">Save changes</button>

                            </div>
                        </div>
                    </div>
                </div>

                <script type="text/javascript">
                    jQuery(document).ready(function($) {
                        $("#table-1").dataTable({
                            "sPaginationType": "bootstrap",
                            "aLengthMenu": [
                                [10, 25, 50, -1],
                                [10, 25, 50, "All"]
                            ],
                            "bStateSave": true
                        });

                        $(".dataTables_wrapper select").select2({
                            minimumResultsForSearch: -1
                        });
                    });
                </script>
                    </div>

                </div>
            </div>

            <!-- Footer -->
            <footer class="main">

                <div class="pull-right">
                    <?php
                    include '../includes/footer.php';
                    ?>
                </div>

            </footer>
        </div>
    </div>

        <link rel="stylesheet" href="../assets/neon/neon-x/assets/js/select2/select2-bootstrap.css" id="style-resource-1">
        <link rel="stylesheet" href="../assets/neon/neon-x/assets/js/select2/select2.css" id="style-resource-2">

        <script src="../assets/neon/neon-x/assets/js/gsap/main-gsap.js" id="script-resource-1"></script>
        <script src="../assets/neon/neon-x/assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js" id="script-resource-2"></script>
        <script src="../assets/neon/neon-x/assets/js/bootstrap.min.js" id="script-resource-3"></script>
        <script src="../assets/neon/neon-x/assets/js/joinable.js" id="script-resource-4"></script>
        <script src="../assets/neon/neon-x/assets/js/resizeable.js" id="script-resource-5"></script>
        <script src="../assets/neon/neon-x/assets/js/neon-api.js" id="script-resource-6"></script>
        <script src="../assets/neon/neon-x/assets/js/jquery.dataTables.min.js" id="script-resource-7"></script>
        <script src="../assets/neon/neon-x/assets/js/dataTables.bootstrap.js" id="script-resource-8"></script>
        <script src="../assets/neon/neon-x/assets/js/select2/select2.min.js" id="script-resource-9"></script>
        <script src="../assets/neon/neon-x/assets/js/neon-chat.js" id="script-resource-10"></script>
        <script src="../assets/neon/neon-x/assets/js/neon-custom.js" id="script-resource-11"></script>
        <script src="../assets/neon/neon-x/assets/js/neon-demo.js" id="script-resource-12"></script>
        <script src="../assets/neon/neon-x/assets/js/toastr.js" id="script-resource-7"></script>


        <script type="text/javascript">
            function updateItem() {
                // alert(args);
                // exit;
                if (confirm("Are you sure you want to dispatch the sample(s)?")) {
                    var notChecked = [],
                        checked = [];
                    $(":checkbox").each(function() {
                        if (this.checked) {
                            checked.push(this.id);
                        } else {
                            notChecked.push(this.id);
                        }
                    });

                    showAjaxModal(checked)
                    $('#samples').html(checked);
                    document.getElementById('samp').value = checked;
                }
            }
        </script>
        <script type="text/javascript">
            function showAjaxModal(s) {

                jQuery('#modal-77').modal('show', {
                    backdrop: 'static'
                });
                //alert(s);
                //exit;
                // jQuery.ajax({
                //     type: "POST",
                //     url: "fac.php",
                //     data: 'id=' + s,
                //     cache: false,
                //     dataType: "json",
                //     success: function(data) {
                //         $.each(data, function(i, v) {
                //             $("#" + i).val(v)

                //         });
                //     }
                // });
            }

            function update(s) {
                //updateAll(checked,0);
                $.ajax({
                    url: 'updateV.php',
                    type: 'POST',
                    data: $("#save_rider").serialize(),
                    dataType: "json",
                    cache: false,
                    success: function(data) {

                        var opts = {
                            "closeButton": true,
                            "debug": false,
                            "positionClass": "toast-top-right",
                            "onclick": null,
                            "sdeDuration": "1000",
                            "tihowDuration": "300",
                            "himeOut": "10000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        };

                        toastr.success(data.message, data.title, opts);
                        setTimeout(function() { // wait for 5 secs(2)
                            location.reload(); // then reload the page.(3)
                        }, 2000);
                    },
                    error: function() {

                        var opts = {
                            "closeButton": true,
                            "debug": false,
                            "positionClass": "toast-top-right",
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        };

                        toastr.success(data.message, data.title, opts);
                    }
                })
            }
        </script>

</body>

</html>