// Get references to the video element and result input box
const videoElement = document.getElementById('qr-video');
const resultElement = document.getElementById('qr-result');

// Check if the browser supports WebRTC and getUserMedia
if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    alert('Your browser does not support QR code scanning.');
} else {
    // Access the device camera
    navigator.mediaDevices.getUserMedia({ video: true })
        .then(handleSuccess)
        .catch(handleError);
}

// Handle successful camera access
function handleSuccess(stream) {
    videoElement.srcObject = stream;

    // Create a QR code scanner instance
    const qrScanner = new Instascan.Scanner({ video: videoElement });

    // Add a listener for QR code detection
    qrScanner.addListener('scan', function(content) {
        resultElement.value = content;
    });

    // Start scanning
    Instascan.Camera.getCameras()
        .then(function(cameras) {
            if (cameras.length > 0) {
                qrScanner.start(cameras[0]);
            } else {
                alert('No cameras found.');
            }
        })
        .catch(handleError);
}

// Handle errors
function handleError(error) {
    console.error('Error accessing the camera:', error);
}
