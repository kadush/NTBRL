<body>

	<div id="footer">
		<div class="content-separator"></div>
		<div class="left">&nbsp;</div>

		<div class="right"> &copy; <?php echo @date('Y');  ?> GOK</div>

		<div class="clearer">&nbsp;</div>

	</div>

	</div>
	</div>

	<script type="text/javascript">
		function GetOfflyn(myval) {
			$.ajax({
				url: "getDisp.php",
				Type: 'POST',
				data: {
					id: myval
				},

				success: function(response) {

					$('#dispatchedD').html(response);
					//	$('#response1').html(response);

				}
			});

			$.ajax({
				url: "getNotDisp.php",
				Type: 'POST',
				data: {
					id: myval
				},

				success: function(response) {

					$('#notdispatchedD').html(response);
					//	$('#worksheet1').html(response);

				}
			});


			
		}

		window.onload = GetOfflyn(<?php echo $FacID ?>);
	</script>
</body>
<?php mysqli_close($dbConn); ?>